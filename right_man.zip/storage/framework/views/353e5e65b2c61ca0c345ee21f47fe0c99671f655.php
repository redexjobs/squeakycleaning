
<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Edit Product</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Edit Product</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						<div class="profile-sidebar">
							<div class="widget-profile pro-widget-content">
								<div class="profile-info-widget">
									<a href="#" class="booking-doc-img">
										<?php if(isset($unserInfo->profile_pic)): ?>
											<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
										<?php else: ?>
											<img src="<?php echo e(asset('public/frontend/img/patients/patient.jpg')); ?>" alt="User Image">
										<?php endif; ?>
									</a>
									<div class="profile-det-info">
										<?php if(!empty(Auth::user()->name)): ?>
									        <h3><?php echo e(Auth::user()->name); ?></h3>
										<?php else: ?>
											<h3>No name</h3>
										<?php endif; ?>
										<div class="patient-details">
											<!--<h5><i class="fas fa-birthday-cake"></i> 24 Jul 1989, 30 years</h5>-->
											<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i><?php if(!empty(Auth::user()->state)): ?> <?php echo e(Auth::user()->state); ?> <?php endif; ?> <?php if(!empty(Auth::user()->country)): ?> <?php echo e(Auth::user()->country); ?> <?php endif; ?></h5>
										</div>
									</div>
								</div>
							</div>
							<div class="dashboard-widget">
								<?php echo $__env->make('doctor/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
					<div class="col-md-7 col-lg-8 col-xl-9">
						<div class="card">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12 col-lg-12">
									   <h4 class="mb-4">Edit Product</h4>
									   <?php if(session()->has('success')): ?>
											<div class="alert alert-success">
											  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

											</div>
										<?php endif; ?>
										<?php if(session()->has('error')): ?>
											<div class="alert alert-danger">
												<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

											</div>
										<?php endif; ?>
										<form role="form" action="<?php echo e(asset('doctor/product/edit_product_action')); ?>" method="POST" enctype='multipart/form-data'>
											<?php echo csrf_field(); ?>
											<input type="hidden" name="product_id" value="<?php echo e($productInfo->id); ?>" required>
											<div class="box-body"> 
												<div class="form-group">
													<label for="exampleInputEmail1">Name <span style="color:red;">*</span></label>
													<input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Name"  value="<?php echo e($productInfo->name); ?>" required>
													<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1">Price <span style="color:red;">*</span></label>
													<input type="number" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Price"   value="<?php echo e($productInfo->price); ?>"  required>
													<?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1">Category <span style="color:red;">*</span></label>
													<select name="category_id" class="form-control" required>
														<option value="">-Select-</option>
														<?php if(isset($categoryList)): ?>
															<?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($categories->id==$productInfo->category_id): ?>
																	<option value="<?php echo e($categories->id); ?>" selected><?php echo e($categories->name); ?></option>
																<?php else: ?>
																	<option value="<?php echo e($categories->id); ?>"><?php echo e($categories->name); ?></option>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php endif; ?>
													</select>
													<?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1">Short Description <span style="color:red;">*</span></label>
													<textarea name="short_description" rows="5" class="form-control <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Short Description" required><?php echo e($productInfo->short_description); ?></textarea>
													<?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1">Description <span style="color:red;">*</span></label>
													<textarea name="description" rows="5" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Description" required><?php echo e($productInfo->description); ?></textarea>
													<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1"><?php echo e(__('Image')); ?> <span style="color:red;">*</span></label>
													<input id="files" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" placeholder="image">
													<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br/>
													<img src="<?php echo e(asset('public/uploads/product/')); ?>/<?php echo e($productInfo->image); ?>" style="width:100px;"/>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1">Status <span style="color:red;">*</span></label>
													<select name="status" class="form-control" required>
														<option value="1" <?php if($productInfo->status==1): ?> selected <?php endif; ?>>Enable</option>
														<option value="0" <?php if($productInfo->status==0): ?> selected <?php endif; ?>>Disable</option>
													</select>
													<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<span class="invalid-feedback" role="alert">
															<strong><?php echo e($message); ?></strong>
														</span>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
											<!-- /.box-body -->
											<div class="box-footer">
												<button type="submit" class="btn btn-primary">Submit</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/product/edit_product.blade.php ENDPATH**/ ?>