
<?php $__env->startSection('title', 'Update Slot'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Update Slot</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Update Slot</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
					<div class="profile-sidebar">
						<div class="widget-profile pro-widget-content">
							<div class="profile-info-widget">
								<a href="#" class="booking-doc-img">
									<?php if(isset($unserInfo->profile_pic)): ?>
										<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
									<?php else: ?>
										<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image" />
									<?php endif; ?>
								</a>
								<div class="profile-det-info">
								    <?php if(!empty(Auth::user()->name)): ?>
									    <h3>Dr. <?php echo e(Auth::user()->name); ?></h3>
									<?php else: ?>
										<h3>Dr. No name</h3>
									<?php endif; ?>
									<div class="patient-details">
										<h5 class="mb-0"><?php if(isset(Auth::user()->doctor_profile_name)): ?> <?php echo e(Auth::user()->doctor_profile_name); ?> <?php endif; ?></h5>
									</div>
								</div>
							</div>
						</div>
						<div class="dashboard-widget">
							<?php echo $__env->make('doctor/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-7 col-lg-8 col-xl-9">
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Update Slot</h4>
									<form name="Schedule-Timings" method="post" action="<?php echo e(url('/doctor/slot_edit_action')); ?>" enctype='multipart/form-data'>
										<?php echo csrf_field(); ?>
										<input type="hidden" name="slot_id" value="<?php echo e($SlotInfo->id); ?>" required>
										<div class="profile-box">
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<label>Timing Slot Duration</label>
														<select class="select form-control <?php $__errorArgs = ['time_duration_slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="time_duration_slot" required>
															<option value="">-Select-</option>
															<option value="15 mins" <?php if($SlotInfo->time_duration_slot=='15 mins'): ?> Selected <?php endif; ?>>15 mins</option>
															<option value="30 mins" <?php if($SlotInfo->time_duration_slot=='30 mins'): ?> Selected <?php endif; ?>>30 mins</option>
															<option value="45 mins" <?php if($SlotInfo->time_duration_slot=='45 mins'): ?> Selected <?php endif; ?>>45 mins</option>
															<option value="1 Hour" <?php if($SlotInfo->time_duration_slot=='1 Hour'): ?> Selected <?php endif; ?>>1 Hour</option>
														</select>
														<?php $__errorArgs = ['time_duration_slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<label>Select Slot Day</label>
														<select class="select form-control  <?php $__errorArgs = ['slot_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="slot_day"  required>
															<option value="">-Select-</option>
															<option value="Sunday" <?php if($SlotInfo->slot_day=='Sunday'): ?> Selected <?php endif; ?>>Sunday</option>
															<option value="Monday" <?php if($SlotInfo->slot_day=='Monday'): ?> Selected <?php endif; ?>>Monday</option>
															<option value="Tuesday" <?php if($SlotInfo->slot_day=='Tuesday'): ?> Selected <?php endif; ?>>Tuesday</option>
															<option value="Wednesday" <?php if($SlotInfo->slot_day=='Wednesday'): ?> Selected <?php endif; ?>>Wednesday</option>
															<option value="Thursday" <?php if($SlotInfo->slot_day=='Thursday'): ?> Selected <?php endif; ?>>Thursday</option>
															<option value="Friday" <?php if($SlotInfo->slot_day=='Friday'): ?> Selected <?php endif; ?>>Friday</option>
															<option value="Saturday" <?php if($SlotInfo->slot_day=='Saturday'): ?> Selected <?php endif; ?>>Saturday</option>
														</select>
														<?php $__errorArgs = ['slot_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<label>From Time</label>
														<input type="text" placeholder="00:00" class="form-control  <?php $__errorArgs = ['from_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_time" value="<?php echo e($SlotInfo->from_time); ?>" required>
														<?php $__errorArgs = ['from_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-lg-2">
													<div class="form-group">
														<label>Select AM/PM</label>
														<select class="select form-control  <?php $__errorArgs = ['from_am_pm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from_am_pm" required>
															<option value="">-Select-</option>
															<option value="AM" <?php if($SlotInfo->from_am_pm=='AM'): ?> Selected <?php endif; ?>>AM</option>
															<option value="PM" <?php if($SlotInfo->from_am_pm=='PM'): ?> Selected <?php endif; ?>>PM</option>
														</select>
														<?php $__errorArgs = ['from_am_pm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<label>To Time</label>
														<input type="text" placeholder="00:00" class="form-control   <?php $__errorArgs = ['to_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_time"  value="<?php echo e($SlotInfo->to_time); ?>" required>
														<?php $__errorArgs = ['to_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-lg-2">
													<div class="form-group">
														<label>Select AM/PM</label>
														<select class="select form-control <?php $__errorArgs = ['to_am_pm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to_am_pm" required>
															<option value="">-Select-</option>
															<option value="AM" <?php if($SlotInfo->to_am_pm=='AM'): ?> Selected <?php endif; ?>>AM</option>
															<option value="PM" <?php if($SlotInfo->to_am_pm=='PM'): ?> Selected <?php endif; ?>>PM</option>
														</select>
														<?php $__errorArgs = ['to_am_pm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-6">
													<div class="form-group">
														<label>Status</label>
														<select class="select form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" required>
															<option value="1" <?php if($SlotInfo->status=='1'): ?> Selected <?php endif; ?>> Enable</option>
															<option value="0" <?php if($SlotInfo->status=='0'): ?> Selected <?php endif; ?>> Disable</option>
														</select>
														<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="submit-section submit-btn-bottom">
												<button type="submit" class="btn btn-primary submit-btn">Submit</button>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/edit_new_slot.blade.php ENDPATH**/ ?>