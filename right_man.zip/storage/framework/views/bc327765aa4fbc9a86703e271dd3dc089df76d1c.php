
<?php $__env->startSection('title', 'Chat'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Chat</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Chat</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						<div class="profile-sidebar">
							<div class="widget-profile pro-widget-content">
								<div class="profile-info-widget">
									<a href="#" class="booking-doc-img">
										 <?php if(isset($unserInfo->profile_pic)): ?>
											<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
										<?php else: ?>
											<img src="<?php echo e(asset('public/frontend/img/patients/patient.jpg')); ?>" alt="User Image">
										<?php endif; ?>
									</a>
									<div class="profile-det-info">
										<?php if(!empty(Auth::user()->name)): ?>
									        <h3><?php echo e(Auth::user()->name); ?></h3>
										<?php else: ?>
											<h3>No name</h3>
										<?php endif; ?>
										<div class="patient-details">
											<!--<h5><i class="fas fa-birthday-cake"></i> 24 Jul 1989, 30 years</h5>-->
											<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i><?php if(!empty(Auth::user()->state)): ?> <?php echo e(Auth::user()->state); ?> <?php endif; ?> <?php if(!empty(Auth::user()->country)): ?> <?php echo e(Auth::user()->country); ?> <?php endif; ?></h5>
										</div>
									</div>
								</div>
							</div>
							<div class="dashboard-widget">
								<?php echo $__env->make('patient/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
					<div class="col-md-7 col-lg-8 col-xl-9">
						
						<div class="chat-window">
							<div class="chat-cont-left">
								<div class="chat-header"><span>Chats</span>
									<a href="javascript:void(0)" class="chat-compose"><i class="material-icons">control_point</i>
									</a>
								</div>
								<div class="chat-users-list">
									<div class="chat-scroll">
									    <?php if(!empty($getUserList)): ?>
											<?php $__currentLoopData = $getUserList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="javascript:void(0);" onclick="goToChat('<?php echo e($userList->id); ?>','<?php echo e($userList->name); ?>','<?php echo e($userList->last_name); ?>','<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($userList->profile_pic); ?>');" class="media read-chat" id="chatID_<?php echo e($userList->id); ?>">
													<div class="media-img-wrap">
														<div class="avatar avatar-away">
															<img src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($userList->profile_pic); ?>" alt="<?php echo e($userList->name); ?>" class="avatar-img rounded-circle">
														</div>
													</div>
													<div class="media-body">
														<div>
															<div class="user-name"><?php echo e($userList->name); ?> <?php echo e($userList->last_name); ?></div>
															<!--<div class="user-last-chat">Hey, How are you?</div>-->
														</div>
														<div>
															<!--<div class="last-chat-time block">2 min</div>
															<div class="badge badge-success badge-pill">0</div>-->
														</div>
													</div>
												</a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
										
									</div>
								</div>
							</div>
							<div class="chat-cont-right">
								<div class="chat-header">
									<a id="back_user_list" href="javascript:void(0)" class="back-user-list"><i class="material-icons">chevron_left</i>
									</a>
									<div class="media">
										<div class="media-img-wrap">
											<div class="avatar avatar-online">
												<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>"  id="singleUserImg" alt="User Image" class="avatar-img rounded-circle">
											</div>
										</div>
										<div class="media-body">
											<div class="user-name" id="singleUserName">Dr. Kalen Chavez</div>
											<div class="user-status">online</div>
										</div>
									</div>
								</div>
								
								<div class="chat-body">
									<div class="chat-scroll">
									   <ul class="list-unstyled" id="chatApp">
									   </ul>
									</div>
								</div>
								
								<div class="chat-footer">
								    <form name="chat-form" method="POST" id="chatForm">
									    <input type="hidden" name="from_id" value="<?php echo e(Auth::user()->id); ?>" required>
									    <input type="hidden" name="to_id" id="to_user_id" required>
										<div class="input-group">
											<input type="text" name="message" class="input-msg-send form-control" placeholder="Type something" required>
											<div class="input-group-append">
												<button type="button" id="submit" class="btn msg-send-btn"><i class="fab fa-telegram-plane"></i>
												</button>
											</div>
										</div>
									</form>
									<script src="<?php echo e(asset('/public/frontend/js/jquery.min.js')); ?>"></script>
									<script>
										function goToChat(to_user_id,first_name,last_name,profile_pic){
											
											gotoChatActionOnLoad(to_user_id);
											$(".read-chat").removeClass('active');
											$("#chatID_"+to_user_id).toggleClass('active');
											$("#singleUserName").html(first_name+' '+last_name);
											$("#singleUserImg").attr('src',profile_pic);
											//$(".chat-body").css('display','none');
											$("#showChatBox_"+to_user_id).css('display','block');
											$("#to_user_id").val(to_user_id);
										}
										
										onloadfunction();
										
										function onloadfunction(){
											$(".read-chat:first-child").click();
										    $(".chat-body:first-child").css( 'display','block' );	  
										}
										
										function gotoChatActionOnLoad(to_id){
											
											var _token = $('meta[name="csrf-token"]').attr('content');
											
											$.ajaxSetup({
												headers: {
												'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
												}
											});
											$.ajax({
												url: "<?php echo e(url('/patient/fetch_user_chat')); ?>",
												type: "GET",
												data: {_token:_token, to_id:to_id},
												success: function(response) {
													$("#chatApp").html(response);
												}
											});
										}
									</script>
									<script>
									$(document).ready(function(){
										$.ajaxSetup({
											headers: {
											'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
											}
										});
										$("#submit").click(function(){
											$("#submit"). attr("disabled", true);
											$.ajax({
												url: "<?php echo e(url('/patient/chat_action')); ?>",
												type: "POST",
												data: $('#chatForm').serialize(),
												success: function(response) {
													$('#submit').html('<i class="fab fa-telegram-plane">');
													document.getElementById("chatForm").reset(); 
												}
											});
										});
										setInterval(function(){
											var toIDS = $("#to_user_id").val();
										 	gotoChatActionOnLoad(toIDS); 
										}, 2000);
									});
									</script>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/patient/chat.blade.php ENDPATH**/ ?>