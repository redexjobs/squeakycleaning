<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<meta name="description" content="">
	<meta name="author" content="">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('public/admin/css/bootstrap.min.css')); ?>">
	<link href="<?php echo e(asset('public/admin/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	<!-- Custom styles for this site -->
	<link href="<?php echo e(asset('public/admin/css/custom.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/admin/css/responsive.css')); ?>" rel="stylesheet">
</head>
<body>
	<main role="main" id="DT-dashboard">
	    <div id="wrapper">
			<aside id="sidebar-wrapper">
				<div class="sidebar-brand">
					<a href="<?php echo e(asset('admin/dashboard')); ?>"><img src="<?php echo e(asset('public/admin/images/logo.png')); ?>" alt="" class="d-block img-fluid" /></a>
				</div>
				<ul class="sidebar-nav">
					<li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>"> <a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
					</li>
					<li class="<?php echo e(Request::is('admin/add-user') ? 'active' : ''); ?> <?php echo e(Request::is('admin/users') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tables" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">User Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tables" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-user')); ?>"> <i class="far fa-circle"></i> Add User</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/users')); ?>"> <i class="far fa-circle"></i> Users</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('/admin/setting')); ?>"><i class="fas fa-tachometer-alt"></i> Setting</a>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-subscription') ? 'active' : ''); ?> <?php echo e(Request::is('admin/subscription') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablessubscription" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Subscription Plan</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablessubscription" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-subscription')); ?>"> <i class="far fa-circle"></i> Add Subscription Plan</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/subscription')); ?>"> <i class="far fa-circle"></i> All Subscription Plan</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-new-service') ? 'active' : ''); ?> <?php echo e(Request::is('admin/service') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesservices" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Services Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesservices" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-new-service')); ?>"> <i class="far fa-circle"></i> Add Services</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/service')); ?>"> <i class="far fa-circle"></i> Services</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-new-training') ? 'active' : ''); ?> <?php echo e(Request::is('admin/training') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablestraining" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Training Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablestraining" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-new-training')); ?>"> <i class="far fa-circle"></i> Add Training</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/training')); ?>"> <i class="far fa-circle"></i> Training</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-shop-category') ? 'active' : ''); ?> <?php echo e(Request::is('admin/shop-category') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesshopcategory" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Shop Category</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesshopcategory" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-shop-category')); ?>"> <i class="far fa-circle"></i> Add shop Category</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/shop-category')); ?>"> <i class="far fa-circle"></i> shop Categories</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-product') ? 'active' : ''); ?> <?php echo e(Request::is('admin/product') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesproduct" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label"> Products</span> <span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesproduct" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-product')); ?>"> <i class="far fa-circle"></i> Add Product</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/product')); ?>"> <i class="far fa-circle"></i> Products</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-course-category') ? 'active' : ''); ?> <?php echo e(Request::is('admin/course-category') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablescoursecategory" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Course Category</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablescoursecategory" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-course-category')); ?>"> <i class="far fa-circle"></i> Add Course Category</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/course-category')); ?>"> <i class="far fa-circle"></i> Course Categories</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-features') ? 'active' : ''); ?> <?php echo e(Request::is('admin/features') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesFeatures" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Features Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesFeatures" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-features')); ?>"> <i class="far fa-circle"></i> Add Features</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/features')); ?>"> <i class="far fa-circle"></i> Features</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-specialities') ? 'active' : ''); ?> <?php echo e(Request::is('admin/specialities') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesSpecialities" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Specialities Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesSpecialities" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-specialities')); ?>"> <i class="far fa-circle"></i> Add Specialities</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/specialities')); ?>"> <i class="far fa-circle"></i> Specialities</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-category') ? 'active' : ''); ?> <?php echo e(Request::is('admin/category') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablescategory" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Blog Category</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablescategory" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-category')); ?>"> <i class="far fa-circle"></i> Add Category</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/category')); ?>"> <i class="far fa-circle"></i> Categories</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-tag') ? 'active' : ''); ?> <?php echo e(Request::is('admin/tag') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablestag" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Tag Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablestag" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-tag')); ?>"> <i class="far fa-circle"></i> Add Tag</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/tag')); ?>"> <i class="far fa-circle"></i> Tag</a>
							</li>
						</ul>
					</li>
					
					<li class="<?php echo e(Request::is('admin/add-blog') ? 'active' : ''); ?> <?php echo e(Request::is('admin/blog') ? 'active' : ''); ?>"> <a href="#" data-toggle="collapse" data-target="#tablesblog" class="active collapsed" aria-expanded="false"><i class="fas fa-table"></i> <span class="nav-label">Blog Management</span><span class="fa fa-chevron-left pull-right"></span></a>
						<ul class="sub-menu collapse" id="tablesblog" style="">
							<li>
								<a href="<?php echo e(asset('admin/add-blog')); ?>"> <i class="far fa-circle"></i> Add Blog</a>
							</li>
							<li>
								<a href="<?php echo e(asset('admin/blog')); ?>"> <i class="far fa-circle"></i> Blog</a>
							</li>
						</ul>
					</li>
				</ul>
			</aside>
			<div id="navbar-wrapper">
				<nav class="navbar navbar-inverse fixed-top">
					<div class="container-fluid">
						<div class="navbar-header"> <a href="#" class="navbar-brand" id="sidebar-toggle"><i class="fa fa-bars"></i></a>
						</div>
						<ul class="custom-navbar-nav">
							<li><a href=""><i class="far fa-bell"></i> <span class="badge badge-light">7</span></a>
							</li>
							<li><a href=""><i class="far fa-envelope"></i> <span class="badge badge-light">7</span></a>
							</li>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<img src="http://via.placeholder.com/30x30" class="rounded-circle" alt="User Image"> <span class="admin-txt"><?php echo e(Auth::user()->name); ?></span>
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
								<a class="dropdown-item" href="<?php echo e(url('admin/profile')); ?>">My Profile</a>
								<a class="dropdown-item" href="<?php echo e(url('admin/setting')); ?>">Settings</a>
								<a class="dropdown-item" href="<?php echo e(url('admin/logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a>
								<form id="logout-form" action="<?php echo e(url('admin/logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
								</div>
						  </li>  
						</ul>
					</div>
				</nav>
			</div>
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</main>
	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="<?php echo e(asset('public/admin/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/dataTables.bootstrap4.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/custom.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/admin/layouts/backend.blade.php ENDPATH**/ ?>