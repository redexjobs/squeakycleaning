
<?php $__env->startSection('title', 'Trainer Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Dashboard</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						<div class="profile-sidebar">
							<div class="widget-profile pro-widget-content">
								<div class="profile-info-widget">
									<a href="#" class="booking-doc-img">
										 <?php if(isset($unserInfo->profile_pic)): ?>
											<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
										<?php else: ?>
											<img src="<?php echo e(asset('public/frontend/img/patients/patient.jpg')); ?>" alt="User Image">
										<?php endif; ?>
									</a>
									<div class="profile-det-info">
										<?php if(!empty(Auth::user()->name)): ?>
									        <h3><?php echo e(Auth::user()->name); ?></h3>
										<?php else: ?>
											<h3>No name</h3>
										<?php endif; ?>
										<div class="patient-details">
											<!--<h5><i class="fas fa-birthday-cake"></i> 24 Jul 1989, 30 years</h5>-->
											<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i><?php if(!empty(Auth::user()->state)): ?> <?php echo e(Auth::user()->state); ?> <?php endif; ?> <?php if(!empty(Auth::user()->country)): ?> <?php echo e(Auth::user()->country); ?> <?php endif; ?></h5>
										</div>
									</div>
								</div>
							</div>
							<div class="dashboard-widget">
								<?php echo $__env->make('trainer/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
					<div class="col-md-7 col-lg-8 col-xl-9">
						<div class="row">
							<div class="col-md-12">
								<div class="card dash-card">
									<div class="card-body">
										<div class="row">
											<div class="col-md-12 col-lg-4">
												<div class="dash-widget dct-border-rht">
													<div class="circle-bar circle-bar1">
														<div class="circle-graph1" data-percent="75">
															<img src="<?php echo e(asset('public/frontend/img/icon-01.png')); ?>" class="img-fluid" alt="patient">
														</div>
													</div>
													<div class="dash-widget-info">
														<h6>Total Course</h6>
														<h3><?php echo e($courseCount); ?></h3>
														<p class="text-muted">Till Today</p>
													</div>
												</div>
											</div>
											<div class="col-md-12 col-lg-4">
												<div class="dash-widget dct-border-rht">
													<div class="circle-bar circle-bar2">
														<div class="circle-graph2" data-percent="65">
															<img src="<?php echo e(asset('public/frontend/img/icon-02.png')); ?>" class="img-fluid" alt="Patient">
														</div>
													</div>
													<div class="dash-widget-info">
														<h6>Today Course Content</h6>
														<h3><?php echo e($coursecontentCount); ?></h3>
														<p class="text-muted"><?php echo e(date('d, M Y')); ?></p>
													</div>
												</div>
											</div>
											<div class="col-md-12 col-lg-4">
												<div class="dash-widget">
													<div class="circle-bar circle-bar3">
														<div class="circle-graph3" data-percent="50">
															<img src="<?php echo e(asset('public/frontend/img/icon-03.png')); ?>" class="img-fluid" alt="Patient">
														</div>
													</div>
													<div class="dash-widget-info">
														<h6>Total Student</h6>
														<h3>0</h3>
														<p class="text-muted"><?php echo e(date('d, M Y')); ?></p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								<br/>
								<div class="card dash-card">
									<div class="card-body">
										<div class="row">
											<div class="col-md-12 col-lg-12">
												<h4>My Current Subscription</h4>
												<?php if(isset($getCurrentSubscriptionPlan)): ?>
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Plan</th>
																	<th>Price</th>
																	<th>Start Date</th>
																	<th>Expiry Date</th>
																	<th>Current Status</th>
																	<th>Action</th>
																</tr>
															</thead>
															<tbody>
																<?php 
																	$subscriptionDate = $getCurrentSubscriptionPlan->created_at;
																	$subscriptionType = $getCurrentSubscriptionPlan->plan_type;
																	$subscriptionDays = $getCurrentSubscriptionPlan->plan_days;
																	
																	$getEndSubscriptionDates = date("Y-m-d", strtotime('+ '.$subscriptionDays.' '.$subscriptionType, strtotime($subscriptionDate)));
																	
																	$getEndSubscriptionDate = date("Y-m-d H:i:s", strtotime('+ '.$subscriptionDays.' '.$subscriptionType, strtotime($subscriptionDate)));

																	$currentDate = date('Y-m-d H:i:s');
																	
																?>
																<tr>
																	<td><?php echo e($getCurrentSubscriptionPlan->plan_name); ?></td>
																	<td>$<?php echo e($getCurrentSubscriptionPlan->plan_price); ?></td>
																	<td><?php echo e(date('Y-m-d',strtotime($getCurrentSubscriptionPlan->created_at))); ?></td>
																	<td><?php echo e($getEndSubscriptionDates); ?></td>
																	<?php if(strtotime($getEndSubscriptionDate)<strtotime($currentDate)): ?>{
																		<td><b style="color:red;">Expired</b></td>
																	<?php else: ?>	
																		<td><b style="color:green;">Active</b></td>
																	<?php endif; ?>	
																	<td>
																		<div class="submit-section">
																			<a href="<?php echo e(url('/subscription-plan')); ?>">
																				<button type="submit" class="btn btn-primary submit-btn">Upgrade</button>
																			</a>
																		</div>
																	</td>
																</tr>			
															</tbody>
														</table>
													</div>
												<?php else: ?>
													<p>You have not any plan.</p>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/trainer/dashboard.blade.php ENDPATH**/ ?>