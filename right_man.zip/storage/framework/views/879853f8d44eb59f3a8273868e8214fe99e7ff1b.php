<?php $__env->startSection('title', $product_details->name); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page"><?php echo e($product_details->name); ?></li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title"><?php echo e($product_details->name); ?></h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
    <!-- Content Start -->
	<section class="content" id="shop-area-details">
		<div class="container">
			<div class="row" style="transform: none;">
				<div class="col-lg-8 col-md-12">
					<div class="blog-view">
						<div class="blog blog-single-post">
							<div class="blog-image">
								<a href="javascript:void(0);">
									<img alt="<?php echo e($product_details->name); ?>" src="<?php echo e(asset('public/uploads/product/')); ?>/<?php echo e($product_details->image); ?>" class="img-fluid">
								</a>
							</div>
						</div>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-12">					
					<h3 class="blog-title"><?php echo e($product_details->name); ?></h3>
					<p><?php echo e($product_details->description); ?></p>
					<h2><i class="fas fa-dollar-sign"></i> <?php echo e($product_details->price); ?></h2>
					<a href="<?php echo e(url('/shop/')); ?>" class="btn book-btn my-3">Add To Cart</a>
				</div>	
			</div>
			<div class="row">		
				<div class="col-md-12 col-sm-12 col-lg-8 col-xl-8">
					<div id="review_form_wrapper" class="review_form_wrapper form-photo-reviews">
						<div id="review_form">
							<div id="respond" class="comment-respond">
								<span id="reply-title" class="comment-reply-title">Add a review</span>
								<form action="" method="post" id="commentform" class="comment-form" novalidate="">
									<p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span>
									</p>
									<div class="comment-form-rating">
										<label for="rating">Your rating&nbsp;<span class="required">*</span>
										</label>
										<p class="stars">	
											<span>							
												<a class="star" href="#">
													<span class="fa fa-star star-active"></span>
													<span class="fa fa-star star-active"></span>
													<span class="fa fa-star star-active"></span>
													<span class="fa fa-star star-active"></span>
													<span class="fa fa-star star-active"></span>
												</a>					
											</span>	
										</p>
										<select name="rating" id="rating" required="" style="display: none;">
											<option value="">Rate…</option>
											<option value="5">Perfect</option>
											<option value="4">Good</option>
											<option value="3">Average</option>
											<option value="2">Not that bad</option>
											<option value="1">Very poor</option>
										</select>
									</div>
									<div  class="form-group">
										<label for="comment">Your review&nbsp;<span class="required">*</span>
										</label>
										<textarea id="comment" name="comment" cols="45" rows="8" required="" class="form-control"></textarea>
									</div>
									<div class="form-group">
										<label for="wcpr_image_upload">Choose pictures<span class="required">*</span> (maxsize: 2000 kB, max files: 2)</label>
										<input type="file" name="wcpr_image_upload[]" id="wcpr_image_upload" class="wcpr_image_upload" multiple="" accept=".jpg, .jpeg, .png, .bmp, .gif">
										<input type="hidden" id="kt_max_files" name="max_files" value="2">
									</div>
									<div class="form-group">
										<label for="author">Name&nbsp;<span class="required">*</span>
										</label>
										<input class="form-control" id="author" name="author" type="text" value="" size="30" required="">
									</div>
									<div class="form-group">
										<label for="email">Email&nbsp;<span class="required">*</span>
										</label>
										<input class="form-control" id="email" name="email" type="email" value="" size="30" required="">
									</div>
									<div class="form-group">
										<div class="form-check">
											<label class="form-check-label">
												<input type="checkbox" class="form-check-input" value="">Save my name, email, and website in this browser for the next time I comment.
											</label>
										</div>
									</div>	
									<button type="submit" class="btn btn-primary submit-btn">Submit</button>
									
								</form>
							</div>
						</div>
					</div>
				</div>
			</div><br/>
			<!--<div class="row mt-4">	 
				<div class="col-md-12 col-sm-12 col-lg-8 col-xl-8">
					<div class="card new-comment clearfix p-4">
						<div class="row d-flex">
							<div class=""> <img class="profile-pic" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg"> </div>
							<div class="d-flex flex-column">
								<h5 class="mt-2 mb-0">Vikram jit Singh</h5>
								<div>
									<p class="text-left"><span class="text-muted">4.0</span> <span class="fa fa-star star-active ml-3"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-inactive"></span></p>
								</div>
							</div>
							<div class="ml-auto">
								<p class="text-muted pt-5 pt-sm-3">06 Nov</p>
							</div>
						</div>
						<div class="row text-left">
							<h4 class="blue-text mt-1">"An awesome activity to experience"</h4>
							<p class="content">If you really enjoy spending your vacation 'on water' or would like to try something new and exciting for the first time.</p>
						</div>		
						<hr>
						<div class="row d-flex">
							<div class=""> <img class="profile-pic" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg"> </div>
							<div class="d-flex flex-column">
								<h5 class="mt-2 mb-0">Vikram jit Singh</h5>
								<div>
									<p class="text-left"><span class="text-muted">4.0</span> <span class="fa fa-star star-active ml-3"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-inactive"></span></p>
								</div>
							</div>
							<div class="ml-auto">
								<p class="text-muted pt-5 pt-sm-3">06 Nov</p>
							</div>
						</div>
						<div class="row text-left">
							<h4 class="blue-text mt-1">"An awesome activity to experience"</h4>
							<p class="content">If you really enjoy spending your vacation 'on water' or would like to try something new and exciting for the first time.</p>
						</div>
						
					</div>
					
				</div>
			</div>-->
			
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/shop_details.blade.php ENDPATH**/ ?>