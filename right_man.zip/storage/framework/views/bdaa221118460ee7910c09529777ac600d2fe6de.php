<?php $__env->startSection('title', 'Order Adult'); ?>
<?php $__env->startSection('content'); ?>
<section class="section section-search">
	<div class="container">
		<div class="banner-wrapper">
			<div class="banner-header text-center">
				<h1>Search Doctor, Make an Appointment</h1>
				<p>Discover the best doctors, clinic & hospital the city nearest to you.</p>
			</div>
			<div class="search-box">
				<form action="search.html">
					<div class="form-group search-location">
						<input type="text" class="form-control" placeholder="Search Location"> <span class="form-text">Based on your Location</span>
					</div>
					<div class="form-group search-info">
						<input type="text" class="form-control" placeholder="Search Doctors, Clinics, Hospitals, Diseases Etc"> <span class="form-text">Ex : Dental or Sugar Check up etc</span>
					</div>
					<button type="submit" class="btn btn-primary search-btn"><i class="fas fa-search"></i>  <span>Search</span>
					</button>
				</form>
			</div>
		</div>
	</div>
</section>
<section class="section section-about">
	<div class="container">
		<div class="section-header text-center">
			<h2>About Older Adult</h2>
			<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-04.png')); ?>" width="60" height="60" />
					</div>
					<h4>Book an Appointment</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-05.png')); ?>" width="60" height="60" />
					</div>
					<h4>Consult with a Doctor</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-06.png')); ?>" width="60" height="60" />
					</div>
					<h4>Make a family Doctor</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section section-doctor">
	<div class="container">
		<div class="row">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2>Book Our Doctor</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="doctor-slider slider">
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-01.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Diedra Spangler</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MDS - Periodontology and Oral Implantology, BDS</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<span class="d-inline-block average-rating">(17)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Florida, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $300 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-02.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Kalen Chavez</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">BDS, MDS - Oral & Maxillofacial Surgery</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(35)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Newyork, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $50 - $300 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-03.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Bedeelia Elliott</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MBBS, MD - General Medicine, DNB - Cardiology</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(27)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Georgia, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $100 - $400 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-04.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Alyxandra Foster</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MBBS, MS - General Surgery, MCh - Urology</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(4)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Louisiana, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $150 - $250 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-05.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Jefferey Candelaria</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MBBS, MD - Ophthalmology, DNB - Ophthalmology</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(66)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Michigan, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $50 - $700 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-06.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="doctor-profile.html">Cerys Fleming</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MS - Orthopaedics, MBBS, M.Ch - Orthopaedics</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(52)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Texas, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $100 - $500 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-07.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="">Bronya Mcclain</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MBBS, MD - General Medicine, DM - Neurology</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(43)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> Kansas, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $100 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
					<div class="profile-widget">
						<div class="doc-img">
							<a href="">
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/frontend/img/doctors/doctor-08.jpg')); ?>">
							</a>
							<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
							</a>
						</div>
						<div class="pro-content">
							<h3 class="title">
						 <a href="doctor-profile.html">Selestine Farmer</a>
						 <i class="fas fa-check-circle verified"></i>
					  </h3>
							<p class="speciality">MBBS, MD - Dermatology , Venereology & Lepros</p>
							<div class="rating"> <i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star filled"></i>
								<i class="fas fa-star"></i>
								<span class="d-inline-block average-rating">(49)</span>
							</div>
							<ul class="available-info">
								<li> <i class="fas fa-map-marker-alt"></i> California, USA</li>
								<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
								<li> <i class="far fa-money-bill-alt"></i> $100 - $400 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
								</li>
							</ul>
							<div class="row row-sm">
								<div class="col-6"> <a href="" class="btn view-btn">View Profile</a>
								</div>
								<div class="col-6"> <a href="" class="btn book-btn">Book Now</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section section-features">
	<div class="container">
		<div class="row">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2 class="mt-2">Availabe Features in Our Clinic</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="features-slider slider">
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-01.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>Patient Ward</p>
					</div>
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-02.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>Test Room</p>
					</div>
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-03.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>ICU</p>
					</div>
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-04.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>Laboratory</p>
					</div>
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-05.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>Operation</p>
					</div>
					<div class="feature-item text-center">
						<img src="<?php echo e(asset('public/frontend/img/features/feature-06.jpg')); ?>" class="img-fluid" alt="Feature">
						<p>Medical</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section section-specialities">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2>Clinic and Specialities</h2>
					<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				</div>
			</div>
		</div>		
		<div class="row justify-content-center">
			<div class="col-md-4">
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-01.png')); ?>" class="img-fluid" alt="Speciality" />
					</div>
					<h4><a href="">Urology</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>	
			<div class="col-md-4">
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-02.png')); ?>" class="img-fluid" alt="Speciality" /> 
					</div>
					<h4><a href="">Neurology</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>
			<div class="col-md-4">	
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-03.png')); ?>" class="img-fluid" alt="Speciality" /> 
					</div>
					<h4><a href="">Orthopedic</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>
			<div class="col-md-4">	
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-04.png')); ?>" class="img-fluid" alt="Speciality" /> 
					</div>
					<h4><a href="">Cardiologist</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>
			<div class="col-md-4">	
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-05.png')); ?>" class="img-fluid" alt="Speciality" /> 
					</div>
					<h4><a href="">Dentist</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>
			<div class="col-md-4">	
				<div class="speicality-item text-center">
					<div class="speicality-img">
						<img src="<?php echo e(asset('public/frontend/img/specialities/specialities-04.png')); ?>" class="img-fluid" alt="Speciality" /> 
					</div>
					<h4><a href="">Cardiologist</a></h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. </p>
				</div>
			</div>
		</div>
		<div class="view-all text-center mt-5"> <a href="" class="btn btn-primary">View All</a>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctor\resources\views/home.blade.php ENDPATH**/ ?>