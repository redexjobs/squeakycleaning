	<nav class="dashboard-menu">
			<ul>
				<li class="<?php echo e(Request::is('doctor/dashboard') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/dashboard')); ?>"><i class="fas fa-columns"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<!--<li class="<?php echo e(Request::is('doctor/appointments') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/appointments')); ?>"><i class="fas fa-calendar-check"></i>
						<span>Appointments</span>
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/patients') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/patients')); ?>"><i class="fas fa-user-injured"></i>
						<span>My Patients</span>
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/schedule-timing') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/add-new-slot') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/schedule-timing')); ?>"><i class="fas fa-hourglass-start"></i>
						<span>Schedule Timings</span>
					</a>
				</li>-->
				<!--<li>
					<a href="<?php echo e(url('/doctor/dashboard')); ?>"><i class="fas fa-file-invoice"></i>
						<span>Invoices</span>
					</a>
				</li>
				<li>
					<a href="<?php echo e(url('/doctor/dashboard')); ?>"><i class="fas fa-star"></i>
						<span>Reviews</span>
					</a>
				</li>
				<li>
					<a href="<?php echo e(url('/doctor/dashboard')); ?>"><i class="fas fa-comments"></i>
						<span>Message</span>
						<small class="unread-msg">23</small>
					</a>
				</li>-->
				<li  class="<?php echo e(Request::is('doctor/profile-setting') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/profile-setting')); ?>"><i class="fas fa-user-cog"></i>
						<span>Profile Settings</span> 
					</a>
				</li>
				<!--<li>
					<a href="<?php echo e(url('/doctor/dashboard')); ?>"><i class="fas fa-share-alt"></i>
						<span>Social Media</span> 
					</a>
				</li>-->
				<li>
				<a href="<?php echo e(url('/doctor/chat')); ?>"><i class="fas fa-comments"></i>
					<span>Chat</span>
					<!--<small class="unread-msg">0</small>-->
				</a>
				<li>
					<a href="<?php echo e(url('/doctor/product')); ?>"><i class="fas fa-columns"></i>
						<span>My Products</span>
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/course') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/add-new-course') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/edit-course/') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/course')); ?>"><i class="fas fa-columns"></i>
						<span>Course</span>
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/course-content') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/add-course-content') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/edit-course-content/') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/course-content')); ?>"><i class="fas fa-columns"></i>
						<span>Course Content</span> 
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/service') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/add-new-service') ? 'active' : ''); ?> <?php echo e(Request::is('doctor/edit-service/') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/service')); ?>"><i class="fas fa-columns"></i>
						<span>Services</span>
					</a>
				</li>
				<li class="<?php echo e(Request::is('doctor/change-password') ? 'active' : ''); ?>">
					<a href="<?php echo e(url('/doctor/change-password')); ?>"><i class="fas fa-lock"></i>
						<span>Change Password</span>
					</a>
				</li>
				<li>
					<a href="<?php echo e(url('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/side_nav.blade.php ENDPATH**/ ?>