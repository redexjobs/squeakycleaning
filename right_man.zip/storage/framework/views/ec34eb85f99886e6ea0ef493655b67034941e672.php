<?php $__env->startSection('title', 'Articles Category'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Articles Category</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Articles Category</h2>
					</div>
				</div>
			</div>
		</section>
<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-md-12">
						<div class="doc-review review-listing">
							<div class="row blog-grid-row">
								<?php if(isset($blogList)): ?>
									<?php $__currentLoopData = $blogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
										<div class="col-md-6 col-xl-6 col-sm-12">
											<div class="blog grid-blog">
												<div class="blog-image">
													<a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>">
														<img class="img-fluid" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($blogs->image); ?>" alt="<?php echo e($blogs->name); ?>">
													</a>
												</div>
												<div class="blog-content">
													<ul class="entry-meta meta-item">
														<li><i class="far fa-clock"></i> <?php echo e(date('d M Y',strtotime($blogs->created_at))); ?></li>
													</ul>
													<h3 class="blog-title"><a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>"><?php echo e($blogs->name); ?></a></h3>
													<p class="mb-0"> <?php echo e($blogs->description); ?></p>
												</div>
											</div>
										</div>
										
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>

							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar">
						<div class="card search-widget">
							<div class="card-body">
								<form class="search-form" method="GET" action="<?php echo e(url('/blog/search')); ?>">
									<div class="input-group">
									    <?php if(!empty($_GET['search'])): ?>
										   <input type="text" name="search" value="<?php echo e($_GET['search']); ?>" placeholder="Search..." class="form-control">
										<?php else: ?>
										   <input type="text" name="search" placeholder="Search..." class="form-control">
										<?php endif; ?>
										<div class="input-group-append">
											<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="card post-widget">
							<div class="card-header">
								<h4 class="card-title">Latest Posts</h4>
							</div>
							<div class="card-body">
								<ul class="latest-posts">
									<?php if(isset($latestPost)): ?>
										<?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestPostList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<div class="post-thumb">
													<a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($latestPostList->slug); ?>">
														<img class="img-fluid" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($latestPostList->image); ?>" alt="<?php echo e($latestPostList->name); ?>">
													</a>
												</div>
												<div class="post-info">
													<h4><a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($latestPostList->slug); ?>"><?php echo e($latestPostList->name); ?></a></h4>
													<p><?php echo e(date('d M Y',strtotime($latestPostList->created_at))); ?></p>
												</div>
											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
						<div class="card category-widget">
							<div class="card-header">
								<h4 class="card-title">Blog Categories</h4>
							</div>
							<div class="card-body">
								<ul class="categories">
									<?php if(isset($blogCat)): ?>
										<?php $__currentLoopData = $blogCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCatList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><a href="<?php echo e(url('/blog/category/')); ?>/<?php echo e($blogCatList->slug); ?>"><?php echo e($blogCatList->name); ?> <span>( <?php echo e($blogCountArray[$blogCatList->id]); ?> )</span></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
						<div class="card tags-widget">
							<div class="card-header">
								<h4 class="card-title">Tags</h4>
							</div>
							<div class="card-body">
								<ul class="tags">
								    <?php if(isset($tagCat)): ?>
										<?php $__currentLoopData = $tagCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagCatList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><a  class="tag" href="<?php echo e(url('/blog/tag/')); ?>/<?php echo e($tagCatList->slug); ?>"><?php echo e($tagCatList->name); ?></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/search.blade.php ENDPATH**/ ?>