<?php $__env->startSection('title', 'Appointment Booking'); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-10 offset-md-1">
					<div class="account-content" id="book-appointment-form">
						<div class="row align-items-center justify-content-center">
							<div class="col-md-7 col-lg-6 login-left">
								<img src="<?php echo e(asset('public/frontend/img/login-banner.png')); ?>" class="img-fluid" alt="Docucare Register">
							</div>
							<div class="col-md-12 col-lg-6 login-right">
								<div class="login-header">
									<h3>Book Appointment Form</h3>
								</div>
								<form action="<?php echo e(url('/appointment_booking_action')); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="doctor_id" value="<?php echo e($doctorInfo->id); ?>" required>
									<input type="hidden" name="customer_id" value="<?php echo e($customerInfo->id); ?>" required>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="text" name="first_name" value="<?php echo e($customerInfo->name); ?>" class="form-control floating" required>
												<label class="focus-label">First Name</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="text" name="last_name" value="<?php echo e($customerInfo->last_name); ?>" class="form-control floating" required>
												<label class="focus-label">Last Name</label>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="email" name="email" value="<?php echo e($customerInfo->email); ?>" class="form-control floating" required>
												<label class="focus-label">Email</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="text" name="doctor_name" value="<?php echo e($doctorInfo->name); ?> <?php echo e($doctorInfo->last_name); ?>" class="form-control floating" required readonly>
												<label class="focus-label">Doctor's Name</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="text" name="hospital_name" class="form-control floating" required>
												<label class="focus-label">Hospital's Name</label>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group form-focus">
												<input type="number" name="mobile_no" value="<?php echo e($customerInfo->mobile_no); ?>" class="form-control floating">
												<label class="focus-label">Mobile Number</label>
											</div>
										</div>	
										<div class="col-md-12">
											<div class="form-group form-focus">											
												<label class="focus-label">Select Preferred Time</label>
												<select name="booking_slot_id" class="form-control" required>
												    <option value="">-Select-</option>
													<?php if(isset($getSlots)): ?>
														<?php $__currentLoopData = $getSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slotList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($slotList->id); ?>"><?php echo e($slotList->slot_day); ?>  <?php echo e($slotList->from_time); ?> <?php echo e($slotList->to_am_pm); ?> To <?php echo e($slotList->to_time); ?> <?php echo e($slotList->from_am_pm); ?> </option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</select>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group form-focus">
												<textarea class="form-control" name="reason_appointment" rows="2" id="comment" required></textarea>
												<label class="focus-label">Reason for the Appointment</label>
											</div>
										</div>	
										
										<button class="btn btn-primary btn-block btn-lg login-btn" type="submit">Get an Appointment</button>
										
									</div>	
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/appointment_booking.blade.php ENDPATH**/ ?>