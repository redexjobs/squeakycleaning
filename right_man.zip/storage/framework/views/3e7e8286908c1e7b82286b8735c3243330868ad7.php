<?php $__env->startSection('title', $trainingInfo->name); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Training Details</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title"><?php echo e($trainingInfo->name); ?></h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
    <!-- Content Start -->
	<section class="content mb-2" id="training-area">
		<div class="container">
			<div class="row" style="transform: none;">
				<div class="col-lg-8 col-md-12">
					<div class="blog-view">
						<div class="blog blog-single-post">
							<div class="blog-image">
								<a href="javascript:void(0);">
									<img alt="" src="<?php echo e(asset('public/uploads/training/')); ?>/<?php echo e($trainingInfo->image); ?>" class="img-fluid">
								</a>
							</div>
							<h3 class="blog-title"><?php echo e($trainingInfo->name); ?></h3>
							<div class="blog-content">
								<p><?php echo e($trainingInfo->description); ?></p>
							</div>
						</div>
						
					</div>
					<div class="card blog-comments clearfix">
							<div class="card-header">
								<h4 class="card-title">Comments (12)</h4>
							</div>
							<div class="card-body pb-0">
								<ul class="comments-list">
									<li>
										<div class="comment">
											<div class="comment-author">
												<img class="avatar" alt="" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg">
											</div>
											<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Agripina Butcher</span>
												</span>
												<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
												<p class="blog-date">Sep 6, 2021</p>
												<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
											</div>
										</div>
										<ul class="comments-list reply">
											<li>
												<div class="comment">
													<div class="comment-author">
														<img class="avatar" alt="" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg">
													</div>
													<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Rima Sisson</span>
														</span>
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
														<p class="blog-date">Sep 6, 2021</p>
														<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
													</div>
												</div>
											</li>
											<li>
												<div class="comment">
													<div class="comment-author">
														<img class="avatar" alt="" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg">
													</div>
													<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Benigno Bingham</span>
														</span>
														<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
														<p class="blog-date">Sep 6, 2021</p>
														<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
													</div>
												</div>
											</li>
										</ul>
									</li>
									<li>
										<div class="comment">
											<div class="comment-author">
												<img class="avatar" alt="" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg">
											</div>
											<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Reina Shumate</span>
												</span>
												<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
												<p class="blog-date">September 6, 2021</p>
											</div>
										</div>
									</li>
									<li>
										<div class="comment">
											<div class="comment-author">
												<img class="avatar" alt="" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg">
											</div>
											<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Mariloly Alicea</span>
												</span>
												<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
												<p class="blog-date">September 6, 2021</p>
												<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					<div class="card new-comment clearfix">
						<div class="card-header">
							<h4 class="card-title">Ask questions</h4>
						</div>
						<div class="card-body">
							<form>
								<div class="form-group">
									<label>Name <span class="text-danger">*</span></label>
									<input type="text" class="form-control">
								</div>
								<div class="form-group">
									<label>Your Email Address <span class="text-danger">*</span></label>
									<input type="email" class="form-control">
								</div>
								<div class="form-group">
									<label>Question</label>
									<textarea rows="4" class="form-control"></textarea>
								</div>
								<div class="submit-section">
									<button class="btn btn-primary submit-btn" type="submit">Submit</button>
								</div>
							</form>
						</div>
					</div>
					<div class="row mt-4">	
						<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
							<div class="card new-comment clearfix p-4">
								<div class="row d-flex">
									<div class=""> <img class="profile-pic" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg"> </div>
									<div class="d-flex flex-column">
										<h5 class="mt-2 mb-0">Vikram jit Singh</h5>
										<div>
											<p class="text-left"><span class="text-muted">4.0</span> <span class="fa fa-star star-active ml-3"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-inactive"></span></p>
										</div>
									</div>
									<div class="ml-auto">
										<p class="text-muted pt-5 pt-sm-3">06 Nov</p>
									</div>
								</div>
								<div class="row text-left">
									<h4 class="blue-text mt-1">"An awesome activity to experience"</h4>
									<p class="content">If you really enjoy spending your vacation 'on water' or would like to try something new and exciting for the first time.</p>
								</div>		
								<hr>
								<div class="row d-flex">
									<div class=""> <img class="profile-pic" src="http://olderadultsonline.com/public/uploads/blog/1635762625.jpg"> </div>
									<div class="d-flex flex-column">
										<h5 class="mt-2 mb-0">Vikram jit Singh</h5>
										<div>
											<p class="text-left"><span class="text-muted">4.0</span> <span class="fa fa-star star-active ml-3"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-active"></span> <span class="fa fa-star star-inactive"></span></p>
										</div>
									</div>
									<div class="ml-auto">
										<p class="text-muted pt-5 pt-sm-3">06 Nov</p>
									</div>
								</div>
								<div class="row text-left">
									<h4 class="blue-text mt-1">"An awesome activity to experience"</h4>
									<p class="content">If you really enjoy spending your vacation 'on water' or would like to try something new and exciting for the first time.</p>
								</div>
								
							</div>
							
						</div>
					</div>
					
				</div>
				<div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">					
					<div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none;">
						<div class="card search-widget">
							<div class="card-body">
								<form class="search-form" method="GET" action="<?php echo e(url('/search-training/')); ?>">
									<div class="input-group">
										<?php if(!empty($_GET['search'])): ?>
											<input type="text" name="search" value="<?php echo e($_GET['search']); ?>" placeholder="Search..." class="form-control" >
										<?php else: ?>
										   <input type="text" name="search" placeholder="Search..." class="form-control">
										<?php endif; ?>	
										<div class="input-group-append">
											<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="card post-widget">
							<div class="card-header">
								<h4 class="card-title">Latest Training Details</h4>
							</div>
							<div class="card-body">
								<ul class="latest-posts">
									<?php if(isset($latesttraining)): ?>
										<?php $__currentLoopData = $latesttraining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latesttrainingList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<div class="post-thumb">
												<a href="">
													<img class="img-fluid" src="<?php echo e(asset('public/uploads/training/')); ?>/<?php echo e($latesttrainingList->image); ?>" alt="<?php echo e($latesttrainingList->image); ?>">
												</a>
											</div>
											<div class="post-info">
												<h4><a href="<?php echo e(url('/training-details/')); ?>/<?php echo e($latesttrainingList->slug); ?>"><?php echo e($latesttrainingList->name); ?></a></h4>
												<p><?php echo e(date('d M Y',strtotime($latesttrainingList->created_at))); ?></p>
											</div>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>	
				</div>	
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/training_details.blade.php ENDPATH**/ ?>