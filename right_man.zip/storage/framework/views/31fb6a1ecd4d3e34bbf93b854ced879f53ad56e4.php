<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Contact</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Contact</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
					<div class="section-header mb-2">
						<h2>Older Adult</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In porta luctus est interdum pretium. Fusce id tortor fringilla, suscipit turpis ac, varius ex.</p>
						<ul class="OA-contact-list shadow p-3 h-100">
							<li><i class="fas fa-map-marker-alt"></i> <span>Address Here</span></li>
							<li><i class="fas fa-phone"></i> <span><a href="tel:123-456-7890">123-456-7890,</a></span></li>
							<li><i class="fas fa-fax"></i> <span><a href="tel:123-456-7890">123-456-7890</a></span></li>
							<li><i class="fas fa-envelope"></i> <span><a href="mailto:example@gmail.com">example@gmail.com</a></span></li>
							<li><i class="far fa-clock"></i> <span>Mon - Sat : 9:00 am - 5:00 pm</span></li>
							<li><i class="far fa-clock"></i> <span>Sunday : Closed</span></li>
						</ul>
					</div>
							
				</div>
				<div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
					<form class="contact-form shadow p-3 h-100" action="" method="POST">
						<div class="form-group">
							<input type="name" class="form-control" placeholder="Name" name="name" required />
						</div>
						<div class="form-group">
							<input type="email" class="form-control" placeholder="Email" name="email" required />
						</div>
						<div class="form-group">
							<input type="number" class="form-control" placeholder="Phone" name="phone" required />
						</div>
						<div class="form-group">
							<textarea class="form-control" type="text" placeholder="Message" rows="6" name="message" required></textarea>
						</div>
						<button type="submit" class="btn btn-submit btn-primary w-100">Submit</button>
					</form>
				</div>
			</div>			
		</div>
	</section>
	<!-- ./ End of Content -->
	<!-- Map Start -->
	<section class="map-area">
		<div class="container-fluid p-0">
			<div class="map-responsive">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227821.9337654486!2d80.80242639305162!3d26.8489293292896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sLucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1631600307312!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>		
		</div>
	</section>
	<!-- ./ End of Map -->
		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/contact_us.blade.php ENDPATH**/ ?>