<?php $__env->startSection('title', 'Search Doctor'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Search</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Search</h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-lg-4 col-xl-3 theiaStickySidebar">
						<div class="card search-filter">
							<div class="card-header">
								<h4 class="card-title mb-0">Search</h4>
							</div>
							<form action="<?php echo e(url('/search-doctor')); ?>" method="GET">
								<?php echo csrf_field(); ?>
								<div class="card-body">
									<div class="filter-widget">
										<div>
										    <?php if(!empty($_GET['search'])): ?>
												<input type="text" name="search" class="form-control" value="<?php echo e($_GET['search']); ?>" placeholder="Search..">
											<?php else: ?>
											    <input type="text" name="search" class="form-control" placeholder="Search..">
											<?php endif; ?>
										</div>
									</div>
									<!--<div class="filter-widget">
										<h4>Gender</h4>
										<div>
											<label class="custom_check">
											<input type="checkbox" name="gender_type[]" value="Male">
											<span class="checkmark"></span> Male</label>
										</div>
										<div>
											<label class="custom_check">
											<input type="checkbox" name="gender_type[]" value="Female">
											<span class="checkmark"></span> Female</label>
										</div>
									</div>-->
									<div class="filter-widget">
										<h4>Select Specialist</h4>
										<?php if(isset($getSpecialities)): ?>
											<?php  if(!empty($_GET['specialist_id'])) { $getArray = $_GET['specialist_id']; }else{ $getArray = array(); } ?>
											<?php $__currentLoopData = $getSpecialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSpecialitiesList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div>
													<label class="custom_check">
													<?php if(in_array($getSpecialitiesList->id,$getArray)): ?>
														<input type="checkbox" name="specialist_id[]" value="<?php echo e($getSpecialitiesList->id); ?>" checked>
													<?php else: ?>
													    <input type="checkbox" name="specialist_id[]" value="<?php echo e($getSpecialitiesList->id); ?>">
													<?php endif; ?>
													<span class="checkmark"></span> <?php echo e($getSpecialitiesList->name); ?></label>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</div>
									<div class="btn-search">
										<button type="submit" class="btn btn-block">Search</button>
									</div>
								</div>
							</form>
						</div>
					</div>
					<div class="col-md-12 col-lg-8 col-xl-9">
						
					<?php if(isset($getSearchData)): ?>	
						<?php $__currentLoopData = $getSearchData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
								<div class="card">
									<div class="card-body">
										<div class="doctor-widget">
											<div class="doc-info-left">
												<div class="doctor-img">
													<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($searchData->id); ?>">
														<img src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($searchData->profile_pic); ?>" class="img-fluid" alt="User Image">
													</a>
												</div>
												<div class="doc-info-cont">
													<h4 class="doc-name"><a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($searchData->id); ?>">Dr. <?php echo e($searchData->name); ?> <?php echo e($searchData->last_name); ?></a></h4>
													<p class="doc-speciality"><?php echo e($searchData->doctor_profile_name); ?></p>
													
													<h5 class="doc-department">
													<img src="<?php echo e(asset('public/uploads/specialities/')); ?>/<?php echo e($searchData->specialities_image); ?>" class="img-fluid" alt="<?php echo e($searchData->specialities_name); ?>"><?php echo e($searchData->specialities_name); ?></h5>
													
													<div class="rating">
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star"></i>
														<span class="d-inline-block average-rating">(17)</span>
													</div>
													<div class="clinic-details">
														<p class="doc-location"><i class="fas fa-map-marker-alt"></i> <?php echo e($searchData->state); ?>, <?php echo e($searchData->country); ?></p>
														
														<ul class="clinic-gallery">
															<?php if(isset($searchData->features_id)): ?>
																<?php 
																	$getFeaturesIds = explode(',',$searchData->features_id);
																?>	
																<?php $__currentLoopData = $getFeaturesIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																    
																	<?php $getFetures = DB::table('features')->where('id',$feature_id)->where('status','1')->first();
																	?>
																	
																	<li>
																		<a href="<?php echo e(asset('public/uploads/features/')); ?>/<?php echo e($getFetures->image); ?>" data-fancybox="gallery">
																			<img src="<?php echo e(asset('public/uploads/features/')); ?>/<?php echo e($getFetures->image); ?>" alt="<?php echo e($getFetures->name); ?>">
																		</a>
																	</li>	
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
														</ul>
													</div>
													<div class="clinic-services">
													   <?php if(isset($searchData->features_id)): ?>
															<?php 
																$getFeaturesIds = explode(',',$searchData->features_id);
															?>	
															<?php $__currentLoopData = $getFeaturesIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																
																<?php $getFetures = DB::table('features')->where('id',$feature_id)->where('status','1')->first();
																?>
																	<span> <?php echo e($getFetures->name); ?></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php endif; ?>
													</div>
												</div>
											</div>
											
											<div class="doc-info-right">
												<div class="clini-infos">
													<ul>
														<li><i class="far fa-thumbs-up"></i> 98%</li>
														<li><i class="far fa-comment"></i> 17 Feedback</li>
														<li><i class="fas fa-map-marker-alt"></i> <?php echo e($searchData->state); ?>, <?php echo e($searchData->country); ?></li>
														<!--<li><i class="far fa-money-bill-alt"></i> $300 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i> 
														</li>-->
													</ul>
												</div>
												<div class="clinic-booking">
													<a class="view-pro-btn" href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($searchData->id); ?>">View Profile</a>
													<!--<a class="apt-btn" href="<?php echo e(url('/book-appointment')); ?>/<?php echo e($searchData->id); ?>">Book Appointment</a>-->
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
						<!--<div class="load-more text-center">
							<a class="btn btn-primary btn-sm" href="javascript:void(0);">Load More</a>
						</div>-->
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/search_doctors.blade.php ENDPATH**/ ?>