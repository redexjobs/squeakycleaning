<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('public/admin/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	<!-- Custom styles for this site -->
	<link href="<?php echo e(asset('public/admin/css/custom.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/admin/css/responsive.css')); ?>" rel="stylesheet">
</head>

<body>
    <main role="main" id="DT-login" class="login-banner">
	  <?php echo $__env->yieldContent('content'); ?>
	</main>
	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="<?php echo e(asset('public/admin/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/admin/js/custom.js')); ?>"></script>
</body>

</html><?php /**PATH /home/u274517282/domains/squeakycleaning.com.au/public_html/app/resources/views/layouts/app.blade.php ENDPATH**/ ?>