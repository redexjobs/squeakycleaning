
<?php $__env->startSection('title', 'Update Profile'); ?>
<?php $__env->startSection('content'); ?>
	<section id="content-wrapper">
		<div class="row">
			<div class="col-lg-12">
				<div class="content-header">
					<div class="row">
						<div class="col-md-6">
							<h2 class="content-title">Dashboard <small class="gray-txt">Control panel</small></h2>
						</div>
						<div class="col-md-6">	
							<div class="page-header-breadcrumb">
								<ul class="breadcrumb">
									<li class="breadcrumb-item">
										<a href="<?php echo e(asset('admin/dashboard')); ?>" data-abc="true">
											<i class="fas fa-tachometer-alt"></i> Home
										</a>
									</li>
									<li class="breadcrumb-item active"><a href="<?php echo e(asset('admin/profile')); ?>" data-abc="true">Profile</a>
									</li>
								</ul>
							</div>
						</div>
					</div>			
				</div>
				<div class="row mt-3">
					<div class="col-md-12">
						<!-- general form elements -->
						<div class="box box-primary">
							<div class="box-header with-border">
								<h3 class="box-title">Update Profile</h3>
							</div>
							<!-- /.box-header -->
							<!-- form start -->
							<?php if(session()->has('success')): ?>
								<div class="alert alert-success">
								  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

								</div>
							<?php endif; ?>
							<?php if(session()->has('error')): ?>
								<div class="alert alert-danger">
									<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

								</div>
							<?php endif; ?>
							<form role="form" action="<?php echo e(asset('admin/update_profile')); ?>" method="POST">
							    <?php echo csrf_field(); ?>
								<div class="box-body">
								    <div class="form-group">
										<label for="exampleInputEmail1">Name</label>
										<input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="<?php echo e($profileInfo->name); ?>" required>
									</div>
									<div class="form-group">
										<label for="exampleInputEmail1">Email</label>
										<input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="<?php echo e($profileInfo->email); ?>" required readonly>
									</div> 
								</div>
								<!-- /.box-body -->
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							</form>
						</div>
						<!-- /.box -->
					</div>
				</div>
					
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a8lajxngzx7y/public_html/resources/views/admin/profile.blade.php ENDPATH**/ ?>