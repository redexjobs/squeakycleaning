
<?php $__env->startSection('title', 'Add New Slot'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Add New Schedule Timing</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Add New Schedule Timing</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
					<div class="profile-sidebar">
						<div class="widget-profile pro-widget-content">
							<div class="profile-info-widget">
								<a href="#" class="booking-doc-img">
									<?php if(isset($unserInfo->profile_pic)): ?>
										<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
									<?php else: ?>
										<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image" />
									<?php endif; ?>
								</a>
								<div class="profile-det-info">
								    <?php if(!empty(Auth::user()->name)): ?>
									    <h3>Dr. <?php echo e(Auth::user()->name); ?></h3>
									<?php else: ?>
										<h3>Dr. No name</h3>
									<?php endif; ?>
									<div class="patient-details">
										<h5 class="mb-0"><?php if(isset(Auth::user()->doctor_profile_name)): ?> <?php echo e(Auth::user()->doctor_profile_name); ?> <?php endif; ?></h5>
									</div>
								</div>
							</div>
						</div>
						<div class="dashboard-widget">
							<?php echo $__env->make('doctor/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-7 col-lg-8 col-xl-9">
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Schedule Timings</h4>
									<form name="Schedule-Timings" method="post" action="<?php echo e(url('/doctor/add_new_slot')); ?>" enctype='multipart/form-data'>
										<?php echo csrf_field(); ?>
										<div class="profile-box">
											<div class="row">
												<div class="col-lg-4">
													<div class="form-group">
														<label>Timing Slot Duration</label>
														<select class="select form-control" name="time_duration_slot" required>
															<option value="">-Select-</option>
															<option value="15 mins">15 mins</option>
															<option value="30 mins">30 mins</option>
															<option value="45 mins">45 mins</option>
															<option value="1 Hour">1 Hour</option>
														</select>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="card schedule-widget mb-0">
														<div class="schedule-header">
															<div class="schedule-nav">
																<ul class="nav nav-tabs nav-justified">
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_sunday">Sunday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#slot_monday">Monday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_tuesday">Tuesday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_wednesday">Wednesday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_thursday">Thursday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_friday">Friday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_saturday">Saturday</a>
																	</li>
																</ul>
															</div>
														</div>
														<div class="tab-content schedule-cont">
															<div id="slot_sunday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
															<div id="slot_monday" class="tab-pane fade show active">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#edit_time_slot"><i class="fa fa-edit mr-1"></i>Edit</a></h4>
																<div class="doc-times">
																	<div class="doc-slot-list">8:00 pm - 11:30 pm
																		<a href="javascript:void(0)" class="delete_schedule"><i class="fa fa-times"></i>
																		</a>
																	</div>
																	<div class="doc-slot-list">11:30 pm - 1:30 pm
																		<a href="javascript:void(0)" class="delete_schedule"><i class="fa fa-times"></i>
																		</a>
																	</div>
																	<div class="doc-slot-list">3:00 pm - 5:00 pm
																		<a href="javascript:void(0)" class="delete_schedule"><i class="fa fa-times"></i>
																		</a>
																	</div>
																	<div class="doc-slot-list">6:00 pm - 11:00 pm
																		<a href="javascript:void(0)" class="delete_schedule"><i class="fa fa-times"></i>
																		</a>
																	</div>
																</div>
															</div>
															<div id="slot_tuesday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
															<div id="slot_wednesday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
															<div id="slot_thursday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
															<div id="slot_friday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
															<div id="slot_saturday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span><a class="edit-link" data-toggle="modal" href="#add_time_slot"><i class="fa fa-plus-circle"></i> Add Slot</a></h4>
																<p class="text-muted mb-0">Not Available</p>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/add_schedule_timing.blade.php ENDPATH**/ ?>