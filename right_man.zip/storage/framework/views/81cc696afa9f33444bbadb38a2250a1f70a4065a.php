<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
	
	<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/frontend/plugins/fontawesome/css/fontawesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/frontend/plugins/fontawesome/css/all.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/responsive.css')); ?>">
</head>
<body>
	<div class="main-wrapper">
		<header class="header">
			<nav class="navbar navbar-expand-lg header-nav">
				<div class="container">
					<div class="navbar-header">
						<a id="mobile_btn" href="javascript:void(0);"> <span class="bar-icon">
					  <span></span>
							<span></span>
							<span></span>
							</span>
						</a>
						<a href="<?php echo e(url('/')); ?>" class="navbar-brand logo">
							<img src="<?php echo e(asset('public/frontend/img/logo.png')); ?>" class="img-fluid" alt="Older Adult" />
						</a>
					</div>
					<div class="main-menu-wrapper">
						<div class="menu-header">
							<a href="<?php echo e(url('/')); ?>" class="menu-logo">
								<img src="<?php echo e(asset('public/frontend/img/logo.png')); ?>" class="img-fluid" alt="Older Adult">
							</a>
							<a id="menu_close" class="menu-close" href="javascript:void(0);"> <i class="fas fa-times"></i>
							</a>
						</div>
						<ul class="main-nav">
							<li class="active"> <a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="has-submenu"> <a href="<?php echo e(url('/')); ?>">Doctors <i class="fas fa-chevron-down"></i></a>
								<ul class="submenu">
									<li><a href="<?php echo e(url('/')); ?>">Doctor Dashboard</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Appointments</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Schedule Timing</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Patients List</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Patients Profile</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Chat</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Invoices</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Profile Settings</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Reviews</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Doctor Register</a>
									</li>
								</ul>
							</li>
							<li class="has-submenu"> <a href="">Patients <i class="fas fa-chevron-down"></i></a>
								<ul class="submenu">
									<li class="has-submenu"> <a href="<?php echo e(url('/')); ?>">Doctors</a>
										<ul class="submenu">
											<li><a href="<?php echo e(url('/')); ?>">Map Grid</a>
											</li>
											<li><a href="<?php echo e(url('/')); ?>">Map List</a>
											</li>
										</ul>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Search Doctor</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Doctor Profile</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Booking</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Checkout</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Booking Success</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Patient Dashboard</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Favourites</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Chat</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Profile Settings</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Change Password</a>
									</li>
								</ul>
							</li>
							<li class="has-submenu"> <a href="<?php echo e(url('/')); ?>">Blog</a>
							<li class="has-submenu"> <a href="<?php echo e(url('/')); ?>">Admin</a>
							</li>
							
							<li class="login-link"> <a href="<?php echo e(url('/')); ?>">Login / Signup</a>
							</li>
						</ul>
					</div>
					<ul class="nav header-navbar-rht">
						<li class="nav-item contact-item">
							<div class="header-contact-img"> <i class="far fa-hospital"></i>
							</div>
							<div class="header-contact-detail">
								<p class="contact-header">Contact</p>
								<p class="contact-info-header">+123 456 7890</p>
							</div>
						</li>
						<li class="nav-item"> <a class="nav-link header-login" href="<?php echo e(url('/')); ?>">login / Signup </a>
						
					</ul>
				</div>	
			</nav>
		</header>
		 <?php echo $__env->yieldContent('content'); ?>
		<footer class="footer">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6">
							<div class="footer-widget footer-about">
								<div class="footer-logo">
									<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/frontend/img/footer-logo.png')); ?>" alt="Older Adult" />
	</a>							</div>
								<div class="footer-about-content">
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<div class="social-icon">
										<ul>
											<li> <a href="<?php echo e(url('/')); ?>"><i class="fab fa-facebook-f"></i> </a>
											</li>
											<li> <a href="<?php echo e(url('/')); ?>"><i class="fab fa-twitter"></i> </a>
											</li>
											<li> <a href="<?php echo e(url('/')); ?>"><i class="fab fa-linkedin-in"></i></a>
											</li>
											<li> <a href="<?php echo e(url('/')); ?>"><i class="fab fa-instagram"></i></a>
											</li>
											<li> <a href="<?php echo e(url('/')); ?>"><i class="fab fa-dribbble"></i> </a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="footer-widget footer-menu">
								<h2 class="footer-title">Important Links</h2>
								<ul>
									<li><a href="<?php echo e(url('/')); ?>">Doctors</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Clinics</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Specialization</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Join as a Doctor</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="footer-widget footer-menu">
								<h2 class="footer-title">For Doctors</h2>
								<ul>
									<li><a href="<?php echo e(url('/')); ?>">Appointments</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Chat</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Login</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Register</a>
									</li>
									<li><a href="<?php echo e(url('/')); ?>">Doctor Dashboard</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="footer-widget footer-contact">
								<h2 class="footer-title">Contact Us</h2>
								<div class="footer-contact-info">
									<div class="footer-address"> <span><i class="fas fa-map-marker-alt"></i></span>
										<p>Please Addres details here..</p>
									</div>
									<p> <i class="fas fa-phone-alt"></i>
										+123 456 7890</p>
									<p class="mb-0"> <i class="fas fa-envelope"></i>
										<a href="mailto:example@gmail.com" class="__cf_email__ text-white">example@gmail.com</a>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="copyright">
						<div class="row">
							<div class="col-md-6 col-lg-6">
								<div class="copyright-text">
									<p class="mb-0">&copy; 2021 Older Adult. All rights reserved.</p>
								</div>
							</div>
							<div class="col-md-6 col-lg-6">
								<div class="copyright-menu">
									<ul class="policy-menu">
										<li><a href="<?php echo e(url('/')); ?>">Terms and Conditions</a>
										</li>
										<li><a href="<?php echo e(url('/')); ?>">Policy</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<script src="<?php echo e(asset('public/frontend/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/frontend/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/frontend/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/frontend/js/slick.js')); ?>"></script>
	<script src="<?php echo e(asset('public/frontend/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH /home/a8lajxngzx7y/public_html/resources/views/layouts/frontend.blade.php ENDPATH**/ ?>