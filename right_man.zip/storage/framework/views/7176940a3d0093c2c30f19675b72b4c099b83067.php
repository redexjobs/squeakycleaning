	<div class="card new-comment clearfix" id="comment_<?php echo e($comment_IDS); ?>" style="display:none;">
		<div class="card-header">
			<h4 class="card-title">Ask questions</h4>
		</div>
		<div class="card-body">
			<form action="<?php echo e(url('/services_comment_action')); ?>" method="POST" >
				<?php echo csrf_field(); ?>
				<input type="hidden" name="current_url" value="<?php echo e($currentURL); ?>" required>
				<input type="hidden" name="services_id" value="<?php echo e($serviceInfo->id); ?>" required>
				<input type="hidden" name="parent_id" value="<?php echo e($parent_id); ?>" required>
				<?php if(!empty(Auth::user()->id)): ?>
					<input type="hidden" name="from_id" value="<?php echo e(Auth::user()->id); ?>" required>
				<?php endif; ?>
				<div class="form-group">
					<label>Name <span class="text-danger">*</span></label>
					<input type="text" name="q_name" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Your Email Address <span class="text-danger">*</span></label>
					<input type="email" name="q_email" class="form-control">
				</div>
				<div class="form-group">
					<label>Question</label>
					<textarea rows="4" name="q_question" class="form-control" required></textarea> 
				</div>
				<div class="submit-section">
					<?php if(auth()->guard()->check()): ?>
						<button class="btn btn-primary submit-btn" type="submit" name="submit" value="submit">Submit</button>
					<?php else: ?> 
						<a href="<?php echo e(url('/login')); ?>"><button class="btn btn-primary submit-btn" type="button" name="submit">Login</button></a>
					<?php endif; ?>
				</div>
			</form>
		</div>
	</div><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/services_comment_form.blade.php ENDPATH**/ ?>