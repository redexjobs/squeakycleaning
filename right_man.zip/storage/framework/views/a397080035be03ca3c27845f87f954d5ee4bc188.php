<?php $__env->startSection('title', 'Services'); ?> 
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Services</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Services</h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
    <!-- Content Start -->
	<section class="content" id="services-area">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-header mb-2">
						<h2>Services Older Adult</h2>						
					</div>	
				</div>				
			</div>
			<div class="row mt-4">
				<?php if(isset($servicesList)): ?>
					<?php $__currentLoopData = $servicesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-6 col-sm-6 col-lg-4 col-xl-4">
							<div class="blog grid-blog">
								<div class="blog-image">
									<a href="<?php echo e(url('/services-details')); ?>/<?php echo e($services->slug); ?>">
										<img class="img-fluid" src="<?php echo e(asset('public/uploads/service/')); ?>/<?php echo e($services->image); ?>" alt="" />
									</a>
								</div>
								<div class="blog-content">
									<h3 class="blog-title"><a href="<?php echo e(url('/services-details')); ?>/<?php echo e($services->slug); ?>"><?php echo e($services->name); ?></a></h3>
									<p><?php echo e($services->short_description); ?></p>
									<i class="far fa-clock"></i> live Session Time : <?php echo e($services->session_time); ?>

									<a href="<?php echo e(url('/services-details')); ?>/<?php echo e($services->slug); ?>" class="btn book-btn my-3">Read More</a>
								</div>
							</div>	
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>		
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/services_page.blade.php ENDPATH**/ ?>