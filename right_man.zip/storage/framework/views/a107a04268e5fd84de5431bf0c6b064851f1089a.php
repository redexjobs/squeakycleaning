
<?php $__env->startSection('title', 'Blog Tags'); ?>
<?php $__env->startSection('content'); ?>
	<section id="content-wrapper">
		<div class="row">
			<div class="col-lg-12">
				<div class="content-header">
					<div class="row">
						<div class="col-md-6">
							<h2 class="content-title">Dashboard <small class="gray-txt">Control panel</small></h2>
						</div>
						<div class="col-md-6">	
							<div class="page-header-breadcrumb">
								<ul class="breadcrumb">
									<li class="breadcrumb-item">
										<a href="<?php echo e(asset('admin/dashboard')); ?>" data-abc="true">
											<i class="fas fa-tachometer-alt"></i> Home
										</a>
									</li>
									<li class="breadcrumb-item active"><a href="<?php echo e(asset('admin/category')); ?>" data-abc="true">Tags</a>
									</li>
								</ul>
							</div>
						</div>
					</div>			
				</div>
				
				<div class="row mt-3">
					<div class="col-lg-12">
					    <?php if(session()->has('success')): ?>
							<div class="alert alert-success">
							  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

							</div>
						<?php endif; ?>
						<?php if(session()->has('error')): ?>
							<div class="alert alert-danger">
								<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

							</div>
						<?php endif; ?>
						<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Name</th>
									<th>Description</th>
									<th>Status</th>
									<th>Created At</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							   <?php if(isset($tags)): ?>
								    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($tag->name); ?></td>
											<td><?php echo e($tag->description); ?></td>
											<?php if($tag->status==1): ?>
												<td>Enable</td>
											<?php else: ?>
											    <td>Disable</td>
										    <?php endif; ?>
											<td><?php echo e($tag->created_at); ?></td>
											<td><a href="<?php echo e(url('/admin/tag/edit')); ?>/<?php echo e($tag->id); ?>"><button type="button" class="btn btn-success">Edit</button></a> <a href="<?php echo e(url('/admin/tag/delete')); ?>/<?php echo e($tag->id); ?>" onclick="return validateDelete(this);"><button type="button" class="btn btn-danger">Delete</button></a></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
							</tbody>
							<tfoot>
								<tr>
									<th>Name</th>
									<th>Description</th>
									<th>Status</th>
									<th>Created At</th>
									<th>Action</th>
								</tr>
							</tfoot>
						</table>
						<script>
						  function validateDelete(){ 
							var confirms = confirm('Do you want to delete ?.');
							if(confirms==false){
								return false;
							}
						  }
						</script>
					</div>		
				</div>
					
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/admin/tag/tag.blade.php ENDPATH**/ ?>