
<?php $__env->startSection('title', 'Appointments'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Appointments</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Appointments</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
					<div class="profile-sidebar">
						<div class="widget-profile pro-widget-content">
							<div class="profile-info-widget">
								<a href="#" class="booking-doc-img">
									<?php if(isset($unserInfo->profile_pic)): ?>
										<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
									<?php else: ?>
										<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image" />
									<?php endif; ?>
								</a>
								<div class="profile-det-info">
								    <?php if(!empty(Auth::user()->name)): ?>
									    <h3>Dr. <?php echo e(Auth::user()->name); ?></h3>
									<?php else: ?>
										<h3>Dr. No name</h3>
									<?php endif; ?>
									<div class="patient-details">
										<h5 class="mb-0"><?php if(isset(Auth::user()->doctor_profile_name)): ?> <?php echo e(Auth::user()->doctor_profile_name); ?> <?php endif; ?></h5>
									</div>
								</div>
							</div>
						</div>
						<div class="dashboard-widget">
							<?php echo $__env->make('doctor/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-7 col-lg-8 col-xl-9">
					<div class="appointments">
						<?php if(isset($getMyAppointment)): ?>
							<?php $__currentLoopData = $getMyAppointment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointmentList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="appointment-list">
									<div class="profile-info-widget">
										<a href="" class="booking-doc-img">
											<img src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($appointmentList->profile_pic); ?>" alt="<?php echo e($appointmentList->name); ?>">
										</a>
										<div class="profile-det-info">
											<h3><?php echo e($appointmentList->name); ?> <?php echo e($appointmentList->last_name); ?></h3>
											<div class="patient-details">
												<h5><i class="far fa-clock"></i> <?php echo e(date('d M Y H:i',strtotime($appointmentList->booking_date_time))); ?></h5>
												<h5><i class="fas fa-map-marker-alt"></i> <?php echo e($appointmentList->state); ?>, <?php echo e($appointmentList->country); ?></h5>
												<h5><i class="fas fa-envelope"></i> <a href="mailto:example@gmail.com" class="__cf_email__"><?php echo e($appointmentList->email); ?></a></h5>
												<h5 class="mb-0"><i class="fas fa-phone"></i> <?php echo e($appointmentList->mobile_no); ?></h5>
											</div>
										</div>
									</div>
									<div class="appointment-action">
										<a href="<?php echo e(url('/doctor/appointment-details/')); ?>/<?php echo e($appointmentList->booking_id); ?>" class="btn btn-sm bg-info-light"><i class="far fa-eye"></i> View</a>
										
										<a href="<?php echo e(url('/doctor/appointment-accept/')); ?>/<?php echo e($appointmentList->booking_id); ?>" class="btn btn-sm bg-success-light"><i class="fas fa-check"></i> Accept</a>
										
										<a href="<?php echo e(url('/doctor/appointment-cancel/')); ?>/<?php echo e($appointmentList->booking_id); ?>" class="btn btn-sm bg-danger-light"><i class="fas fa-times"></i> Cancel</a>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
												
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/appointments.blade.php ENDPATH**/ ?>