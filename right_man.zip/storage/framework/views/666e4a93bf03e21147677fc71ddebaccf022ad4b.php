<?php $__env->startSection('title', 'Setting'); ?>
<?php $__env->startSection('content'); ?>
	<section id="content-wrapper">
		<div class="row">
			<div class="col-lg-12">
				<div class="content-header">
					<div class="row">
						<div class="col-md-6">
							<h2 class="content-title">Dashboard <small class="gray-txt">Control panel</small></h2>
						</div>
						<div class="col-md-6">	
							<div class="page-header-breadcrumb">
								<ul class="breadcrumb">
									<li class="breadcrumb-item">
										<a href="<?php echo e(asset('admin/dashboard')); ?>" data-abc="true">
											<i class="fas fa-tachometer-alt"></i> Home
										</a>
									</li>
									<li class="breadcrumb-item active"><a href="<?php echo e(asset('admin/setting')); ?>" data-abc="true">Setting</a>
									</li>
								</ul>
							</div>
						</div>
					</div>			
				</div>
				<div class="row mt-3">
					<div class="col-md-12">
						<!-- general form elements -->
						<div class="box box-primary">
							<div class="box-header with-border">
								<h3 class="box-title">Setting</h3>
							</div>
							<!-- /.box-header -->
							<!-- form start -->
							<?php if(session()->has('success')): ?>
								<div class="alert alert-success">
								  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

								</div>
							<?php endif; ?>
							<?php if(session()->has('error')): ?>
								<div class="alert alert-danger">
									<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

								</div>
							<?php endif; ?>
							<form role="form" action="<?php echo e(asset('admin/global_setting_action')); ?>" method="POST"  enctype='multipart/form-data'>
							    <?php echo csrf_field(); ?>
								<?php if(isset($settingInfo->id)): ?>
								   <input type="hidden" name="setting_id" value="<?php echo e($settingInfo->id); ?>" required>
								<?php endif; ?>
								<div class="box-body">
								    <div class="form-group">
										<label for="exampleInputEmail1">Email</label>
										<?php if(isset($settingInfo->admin_email)): ?>
										   <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email.." value="<?php echo e($settingInfo->admin_email); ?>">
									    <?php else: ?>
											<input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email..">
										<?php endif; ?>
									</div>
									<div class="form-group">
										<label for="exampleInputEmail1"><?php echo e(__('Header Logo')); ?></label>
										<input id="files" type="file" class="form-control <?php $__errorArgs = ['header_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="header_logo" placeholder="Header Logo..">
										<?php $__errorArgs = ['header_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										<br/>
										<?php if(isset($settingInfo->header_logo)): ?>
										   <img src="<?php echo e(asset('public/uploads/setting/')); ?>/<?php echo e($settingInfo->header_logo); ?>" height="70">
										<?php endif; ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1">Header Contact Details</label>
										<?php if(isset($settingInfo->header_contact_details)): ?>
										    <textarea name="header_contact_details" rows="5" class="form-control <?php $__errorArgs = ['header_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Header contact Details.."><?php echo e($settingInfo->header_contact_details); ?></textarea>
										<?php else: ?>
											<textarea name="header_contact_details" rows="5" class="form-control <?php $__errorArgs = ['header_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Header contact Details.."></textarea>
										<?php endif; ?>
										<?php $__errorArgs = ['header_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1"><?php echo e(__('Footer Logo')); ?></label>
										<input id="files" type="file" class="form-control <?php $__errorArgs = ['footer_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="footer_logo" placeholder="Footer Logo..">
										<?php $__errorArgs = ['footer_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										<br/>
										<?php if(isset($settingInfo->footer_logo)): ?>
										   <img src="<?php echo e(asset('public/uploads/setting/')); ?>/<?php echo e($settingInfo->footer_logo); ?>" height="70" style="background: currentColor;">
										<?php endif; ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1">Footer Description</label>
										<?php if(isset($settingInfo->footer_description)): ?>
										    <textarea name="footer_description" rows="5" class="form-control <?php $__errorArgs = ['footer_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer description.."><?php echo e($settingInfo->footer_description); ?></textarea>
										<?php else: ?>
											<textarea name="footer_description" rows="5" class="form-control <?php $__errorArgs = ['footer_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer description...."></textarea>
										<?php endif; ?>
										<?php $__errorArgs = ['footer_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1">Footer Social Media</label>
										<?php if(isset($settingInfo->footer_social_media)): ?>
										    <textarea name="footer_social_media" rows="5" class="form-control <?php $__errorArgs = ['footer_social_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Social media here...."><?php echo e($settingInfo->footer_social_media); ?></textarea>
										<?php else: ?>
											<textarea name="footer_social_media" rows="5" class="form-control <?php $__errorArgs = ['footer_social_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Social media here...."></textarea>
										<?php endif; ?>
										<?php $__errorArgs = ['footer_social_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1">Footer Copy Right Content</label>
										<?php if(isset($settingInfo->footer_copyright)): ?>
										    <textarea name="footer_copyright" rows="5" class="form-control <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Social media here...."><?php echo e($settingInfo->footer_copyright); ?></textarea>
										<?php else: ?>
											<textarea name="footer_copyright" rows="5" class="form-control <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Copy Right Content.."></textarea>
										<?php endif; ?>
										<?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="form-group">
										<label for="exampleInputEmail1">Footer Contact Details</label>
										<?php if(isset($settingInfo->footer_contact_details)): ?>
										    <textarea name="footer_contact_details" rows="5" class="form-control <?php $__errorArgs = ['footer_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Contact Details.."><?php echo e($settingInfo->footer_contact_details); ?></textarea>
										<?php else: ?>
											<textarea name="footer_contact_details" rows="5" class="form-control <?php $__errorArgs = ['footer_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" placeholder="Footer Contact Details.."></textarea>
										<?php endif; ?>
										<?php $__errorArgs = ['footer_contact_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									 
								</div>
								<!-- /.box-body -->
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							</form>
						</div>
						<!-- /.box -->
					</div>
				</div>
					
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u274517282/domains/squeakycleaning.com.au/public_html/app/resources/views/admin/setting.blade.php ENDPATH**/ ?>