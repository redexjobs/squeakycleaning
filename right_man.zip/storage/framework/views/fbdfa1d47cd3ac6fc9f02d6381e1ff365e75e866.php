<?php $__env->startSection('title', 'Older Adult'); ?>
<?php $__env->startSection('content'); ?>
<section class="section section-search">
	<div class="container">
		<div class="banner-wrapper">
			<div class="banner-header text-center">
				<!--<h1>Search Specialities Doctor's, Make an Appointment</h1>-->
				<h1>Search our List of Medical Doctors and or Specialists</h1>
				<p>Discover the best doctors, of the city nearest to you.</p>
			</div>
			<div class="search-box">
				<form action="<?php echo e(url('/search-doctor')); ?>" method="GET">
				   <?php echo csrf_field(); ?>
					<div class="form-group search-location">
						<!--<input type="text" class="form-control" placeholder="Search Location"> <span class="form-text">Based on your Location</span>-->
					</div>
					<div class="form-group search-info">
						<input type="text" class="form-control" name="search" placeholder="Search Specialities Doctors.."> <span class="form-text">Ex : Search Specialities Doctor's. like Urology,cardiology etc.</span>
					</div>
					<button type="submit" class="btn btn-primary search-btn"><i class="fas fa-search"></i>  <span>Search</span>
					</button> 
				</form>
			</div>
		</div>
	</div>
</section>
<section class="section section-about">
	<div class="container">
		<div class="section-header text-center">
			<h2>About Older Adult</h2>
			<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-04.png')); ?>" width="60" height="60" />
					</div>
					<!--<h4>Book an Appointment</h4>-->
					<h4>Medical Doctors | Specialists</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-05.png')); ?>" width="60" height="60" />
					</div>
					<!--<h4>Consult with a Doctor</h4>-->
					<h4>Training | Courses</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="feature-box text-center">
					<div class="feature-img mb-2">
						<img alt="Book an Appointment" src="<?php echo e(asset('public/frontend/img/icon-06.png')); ?>" width="60" height="60" />
					</div>
					<!--<h4>Make a family Doctor</h4>-->
					<h4>Latest Medical Articles</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section section-doctor">
	<div class="container">
	    <?php if(isset($getDoctors)): ?>	
			
			<div class="row">
				<div class="col-md-10 offset-md-1">
					<div class="section-header text-center">
						<!--<h2>Book Our Doctor</h2>-->
						<h2>Our Doctors and or Specialists</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="doctor-slider slider">
						
					<?php $__currentLoopData = $getDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctorList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
						<div class="profile-widget">
							<div class="doc-img">
								<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>">
									<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($doctorList->profile_pic); ?>">
								</a>
								<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
								</a>
							</div>
							<div class="pro-content">
								<h3 class="title">
							 <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>"><?php echo e($doctorList->name); ?> <?php echo e($doctorList->last_name); ?></a>
							 <i class="fas fa-check-circle verified"></i>
						  </h3>
								<p class="speciality"><?php echo e($doctorList->doctor_profile_name); ?> <?php echo e($doctorList->specialities_name); ?></p>
								<div class="rating"> <i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<span class="d-inline-block average-rating">(17)</span>
								</div>
								<ul class="available-info">
									<li> <i class="fas fa-map-marker-alt"></i> <?php echo e($doctorList->state); ?>, <?php echo e($doctorList->country); ?></li>
									<!--<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
									<li> <i class="far fa-money-bill-alt"></i> $300 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
									</li>-->
								</ul>
								<!--<div class="row row-sm">
									<div class="col-6"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn view-btn">View Profile</a>
									</div>
									<div class="col-6"> <a href="<?php echo e(url('/book-appointment')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">Book Now</a>
									</div>
								</div>-->
								<div class="row row-sm">
									<div class="offset-0 col-12"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">View Profile</a>
									</div>
								</div>
							</div>
						</div>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					
						
						
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</section>
<section class="section section-features">
	<div class="container">
		<div class="row">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2 class="mt-2">Available Training and or Courses</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="features-slider slider">
					<?php if(isset($courseCategoryList)): ?>
						<?php $__currentLoopData = $courseCategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseCategoryLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="feature-item text-center">
								<img src="<?php echo e(asset('public/uploads/course_category/')); ?>/<?php echo e($courseCategoryLists->image); ?>" class="img-fluid" alt="<?php echo e($courseCategoryLists->name); ?>">
								<p><?php echo e($courseCategoryLists->name); ?></p>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					<?php endif; ?>		
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section section-specialities">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<!--<h2>Clinic and Specialities</h2>-->
					<h2>Medical Specialties and Subspecialties</h2>
					<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				</div>
			</div>
		</div>		
		<div class="row justify-content-center">
			<?php if(isset($getSpecialities)): ?>
				<?php $__currentLoopData = $getSpecialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4">
						<div class="speicality-item text-center">
							<div class="speicality-img">
								<img src="<?php echo e(asset('public/uploads/specialities/')); ?>/<?php echo e($specialities->image); ?>" class="img-fluid" alt="<?php echo e($specialities->name); ?>">
							</div>
							<h4><a href="<?php echo e(url('/')); ?>"><?php echo e($specialities->name); ?></a></h4>
							<p><?php echo e($specialities->description); ?></p>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			
		</div>
		<div class="view-all text-center mt-5"> <a href="<?php echo e(url('/specialization')); ?>" target="_blank" class="btn btn-primary">View All</a>
		</div>
	</div>
</section>

<section class="section section-about">
	<div class="container">
		<div class="section-header text-center">
			<h2>Our latest articles</h2>
			<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="doc-review">
					<div class="row blog-grid-row">
						<?php if(isset($latestPost)): ?>
							<?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-6 col-xl-4 col-sm-12">
									<div class="blog grid-blog">
										<div class="blog-image">
											<a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>">
												<img class="img-fluid" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($blogs->image); ?>" alt="<?php echo e($blogs->name); ?>">
											</a>
										</div>
										<div class="blog-content">
											<ul class="entry-meta meta-item">
												<li><i class="far fa-clock"></i> <?php echo e(date('d M Y',strtotime($blogs->created_at))); ?></li>
											</ul>
											<h3 class="blog-title"><a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>"><?php echo e($blogs->name); ?></a></h3>
											<p class="mb-0"> <?php echo e($blogs->description); ?></p>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>			
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/home.blade.php ENDPATH**/ ?>