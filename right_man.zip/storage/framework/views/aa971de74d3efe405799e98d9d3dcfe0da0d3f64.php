<?php $__env->startSection('title', 'Specialization'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Specialization</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Specialization</h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="section section-specialities">
	<div class="container">
		<!--<div class="row justify-content-center">
			<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2>Clinic and Specialities</h2>
					<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				</div>
			</div>
		</div>-->		
		<div class="row justify-content-center">
			<?php if(isset($getSpecialities)): ?>
				<?php $__currentLoopData = $getSpecialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4">
						<div class="speicality-item text-center">
							<div class="speicality-img">
								<img src="<?php echo e(asset('public/uploads/specialities/')); ?>/<?php echo e($specialities->image); ?>" class="img-fluid" alt="<?php echo e($specialities->name); ?>">
							</div>
							<h4><a href="<?php echo e(url('/')); ?>"><?php echo e($specialities->name); ?></a></h4>
							<p><?php echo e($specialities->description); ?></p>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>	
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/specialization.blade.php ENDPATH**/ ?>