	<nav class="dashboard-menu">
		<ul>
			<li class="<?php echo e(Request::is('patient/dashboard') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/patient/dashboard')); ?>"><i class="fas fa-columns"></i>
					<span>Dashboard</span>
				</a>
			</li>
			<!--<li>
				<a href="<?php echo e(url('/patient/dashboard')); ?>"><i class="fas fa-bookmark"></i>
					<span>Favourites</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(url('/patient/dashboard')); ?>"><i class="fas fa-users"></i>
					<span>Dependent</span>
				</a>
			</li>-->
			<li>
				<a href="<?php echo e(url('/patient/chat')); ?>"><i class="fas fa-comments"></i>
					<span>Chat</span>
					<!--<small class="unread-msg">0</small>-->
				</a>
			</li>
			<li class="<?php echo e(Request::is('patient/profile-setting') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/patient/profile-setting')); ?>"><i class="fas fa-user-cog"></i>
					<span>Profile Settings</span>
				</a>
			</li>
			<li class="<?php echo e(Request::is('patient/change-password') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/patient/change-password')); ?>"><i class="fas fa-lock"></i>
					<span>Change Password</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(url('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
					<span>Logout</span>
				</a>
			</li>
		</ul>
	</nav><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/patient/side_nav.blade.php ENDPATH**/ ?>