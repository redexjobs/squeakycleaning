<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">About</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">About</h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-lg-6 col-xl-6 d-block d-md-block d-sm-block d-lg-none d-xl-none">
					<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-08.jpg')); ?>" alt="" class="mx-auto d-block w-100 img-fluid mb-3" />
				</div>
				<div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
					<div class="section-header mb-2">
						<h2>About Older Adult</h2>
						<p>Technology derived health care also known as tele-health or e-health can help people to access the necessary health care they require and want. Olderadultsonline.com is dedicated to providing a platform where older adults can safely and easily submit questions regarding aging, health and wellbeing, which will be answered during our live online sessions. We will also host live online sessions to provide information regarding the use of online health related resources to help you manage your own health and wellbeing. Please visit our live <a href="">Consultation and Q & A page</a> to learn more about this service </p>
						<p>Olderadultsonline.com is also dedicated to providing accurate and relevant information regarding the use of wearable technology and devices, which includes smart watches, bracelets, etc. These devices can act as medical alert devices, fitness trackers or even monitor chronic conditions. Please visit our <a href="">wearable tech page</a> to learn more about the types of devices, how they work and the one best suited to your needs. </p>
						<p>Olderadultsonline.com also provides an expertise exchange service. This service provides a platform where older adults with expertise in a certain area can share their skills with other’s via online sessions. As a presenter or expertise exchanger, you can receive remuneration for each attendee that joins your session or class. Please see our <a href="">expertise exchange page</a> for more information.</p>
					</div>	
				</div>
				<div class="col-md-12 col-sm-12 col-lg-6 col-xl-6 d-none d-md-none d-sm-none d-lg-block d-xl-block">
					<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-08.jpg')); ?>" alt="" class="mx-auto d-block w-100 img-fluid" />
					<div class="row">
						<div class="col-md-6 col-sm-6 col-lg-12 col-xl-12">
							<div class="aboutBox">
								<div class="icon">
									<i class="fas fa-user-md"></i>
								</div>
								<div class="aboutcontent">
									<h6>Experted Doctors</h6>
									<p>Cras vel metus ligula. Nam enim ligula</p>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-12 col-xl-12">
							<div class="aboutBox">
								<div class="icon">
									<i class="fas fa-clinic-medical"></i>
								</div>
								<div class="aboutcontent">
									<h6>Healthy Environment</h6>
									<p>Cras vel metus ligula. Nam enim ligula</p>
								</div>
							</div>
						</div>
					</div>	
				</div>
			</div>			
		</div>
	</section>
	<!-- ./ End of Content -->
	<!-- Section-doctor Start -->
	<section class="section banner1 py-4" style="background: url( <?php echo e(asset('public/frontend/img/banner-bg.jpg')); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-lg-9 col-xl-9">
					<p class="text-white m-0">We Are All Ready For Your Requests, Just Make Appointment</p>
					<h2 class="text-white m-0">Don't Hesitate To Be In Touch</h2>
				</div>
				<div class="col-md-12 col-sm-12 col-lg-3 col-xl-3">
					<a href="" class="btn btn-primary">Make Appointment</a>
				</div>
			</div>
		</div>
	</section>		
	<!-- Section-doctor Start -->
	
	<section class="section py-5">
	<div class="container">
	    <?php if(isset($getDoctors)): ?>	
			
			<div class="row">
				<div class="col-md-10 offset-md-1">
					<div class="section-header text-center">
						<!--<h2>Book Our Doctor</h2>-->
						<h2>Our Doctors and or Specialists</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="doctor-slider slider">
						
					<?php $__currentLoopData = $getDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctorList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
						<div class="profile-widget">
							<div class="doc-img">
								<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>">
									<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($doctorList->profile_pic); ?>">
								</a>
								<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
								</a>
							</div>
							<div class="pro-content">
								<h3 class="title">
							 <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>"><?php echo e($doctorList->name); ?> <?php echo e($doctorList->last_name); ?></a>
							 <i class="fas fa-check-circle verified"></i>
						  </h3>
								<p class="speciality"><?php echo e($doctorList->doctor_profile_name); ?> <?php echo e($doctorList->specialities_name); ?></p>
								<div class="rating"> <i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<span class="d-inline-block average-rating">(17)</span>
								</div>
								<ul class="available-info">
									<li> <i class="fas fa-map-marker-alt"></i> <?php echo e($doctorList->state); ?>, <?php echo e($doctorList->country); ?></li>
									<!--<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
									<li> <i class="far fa-money-bill-alt"></i> $300 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
									</li>-->
								</ul>
								<!--<div class="row row-sm">
									<div class="col-6"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn view-btn">View Profile</a>
									</div>
									<div class="col-6"> <a href="<?php echo e(url('/book-appointment')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">Book Now</a>
									</div>
								</div>-->
								<div class="row row-sm">
									<div class="offset-0 col-12"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">View Profile</a>
									</div>
								</div>
							</div>
						</div>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					
						
						
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</section>
	<!-- ./ End of Section-doctor -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/about_us.blade.php ENDPATH**/ ?>