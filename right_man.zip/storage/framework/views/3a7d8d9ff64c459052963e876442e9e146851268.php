
<?php $__env->startSection('title', 'Schedule Timing'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Schedule Timing</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Schedule Timing</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
					<div class="profile-sidebar">
						<div class="widget-profile pro-widget-content">
							<div class="profile-info-widget">
								<a href="#" class="booking-doc-img">
									<?php if(isset($unserInfo->profile_pic)): ?>
										<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
									<?php else: ?>
										<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image" />
									<?php endif; ?>
								</a>
								<div class="profile-det-info">
								    <?php if(!empty(Auth::user()->name)): ?>
									    <h3>Dr. <?php echo e(Auth::user()->name); ?></h3>
									<?php else: ?>
										<h3>Dr. No name</h3>
									<?php endif; ?>
									<div class="patient-details">
										<h5 class="mb-0"><?php if(isset(Auth::user()->doctor_profile_name)): ?> <?php echo e(Auth::user()->doctor_profile_name); ?> <?php endif; ?></h5>
									</div>
								</div>
							</div>
						</div>
						<div class="dashboard-widget">
							<?php echo $__env->make('doctor/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-7 col-lg-8 col-xl-9">
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-body">
									<h4 class="card-title">Schedule Timings</h4>
										<div class="profile-box">
										    <?php if(session()->has('success')): ?>
												<div class="alert alert-success">
												  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

												</div>
											<?php endif; ?>
											<?php if(session()->has('error')): ?>
												<div class="alert alert-danger">
													<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

												</div>
											<?php endif; ?>
											<div class="row">
												<div class="col-lg-12">
													<div class="submit-section submit-btn-bottom">
														<a href="<?php echo e(url('/doctor/add-new-slot')); ?>"><button type="button" class="btn btn-primary submit-btn">Add New Slot</button></a>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="card schedule-widget mb-0">
														<div class="schedule-header">
															<div class="schedule-nav">
																<ul class="nav nav-tabs nav-justified">
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_sunday" id="slotSunday">Sunday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#slot_monday" id="slotMonday">Monday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_tuesday" id="slotTuesday">Tuesday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_wednesday" id="slotWednesday">Wednesday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_thursday" id="slotThursday">Thursday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_friday" id="slotFriday">Friday</a>
																	</li>
																	<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#slot_saturday" id="slotSaturday">Saturday</a>
																	</li>
																</ul>
															</div>
														</div>
														<div class="tab-content schedule-cont">
															<div id="slot_sunday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getSundaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getSundaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															<div id="slot_monday" class="tab-pane fade show active">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getMondaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getMondaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															
															<div id="slot_tuesday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getTuesdaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getTuesdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															
															<div id="slot_wednesday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getWednesdaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getWednesdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															
															<div id="slot_thursday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getThursdaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getThursdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															<div id="slot_friday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getFridaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getFridaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
															<div id="slot_saturday" class="tab-pane fade">
																<h4 class="card-title d-flex justify-content-between"><span>Time Slots</span>
																</h4>
																<?php if(isset($getSaturdaySlot)): ?>
																	<div class="table-responsive">
																		<table class="table table-hover table-center mb-0">
																			<thead>
																				<tr>
																					<th>Time Duration</th>
																					<th>Day</th>
																					<th>Time</th>
																					<th>Status</th>
																					<th>Action</th>
																				</tr>
																			</thead>
																			<tbody>
																			    <?php $__currentLoopData = $getSaturdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getSlotData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																					<tr>
																						<td><?php echo e($getSlotData->time_duration_slot); ?></td>
																						<td><?php echo e($getSlotData->slot_day); ?></td>
																						<td>
																							<div class="doc-slot-list" style="width: 190px;">
																							<?php echo e($getSlotData->from_time); ?> <?php echo e($getSlotData->from_am_pm); ?> - <?php echo e($getSlotData->to_time); ?> <?php echo e($getSlotData->to_am_pm); ?>

																								<a class="delete_schedule"><i class="fa fa-clock"></i>
																								</a>
																							</div>
																						</td>
																						<?php if($getSlotData->status=='1'): ?>
																						    <td>Enable</td>
																						<?php else: ?>
																							<td>Disable</td>
																						<?php endif; ?>
																						<td><a class="edit-link" href="<?php echo e(url('/doctor/slot-edit/')); ?>/<?php echo e($getSlotData->id); ?>"><i class="fa fa-edit mr-1"></i>Edit</a> /&nbsp; 
																						<a class="edit-link" style="color:#d43f3a;"   href="<?php echo e(url('/doctor/slot-delete/')); ?>/<?php echo e($getSlotData->id); ?>"  onclick="return validateDelete(this);"><i class="fa fa-trash mr-1"></i>Delete</a></td>
																					</tr>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</tbody>
																		</table>
																	</div>
																<?php else: ?>
																    <p class="text-muted mb-0">Not Available</p>
																<?php endif; ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<script>
		function validateDelete(){ 
			var confirms = confirm('Do you want to delete ?.');
			if(confirms==false){
				return false;
			}
		}
	</script>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor/schedule_timing.blade.php ENDPATH**/ ?>