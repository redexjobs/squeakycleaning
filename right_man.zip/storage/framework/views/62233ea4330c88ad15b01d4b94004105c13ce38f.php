
<?php $__env->startSection('title', 'Course Content'); ?>
<?php $__env->startSection('content'); ?>
	<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Course Content</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Course Content</h2>
				</div>
			</div>
		</div>
	</section> 
	<!-- ./ End of Breadcrumb-bar -->
	<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
					<div class="profile-sidebar">
						<div class="widget-profile pro-widget-content">
							<div class="profile-info-widget">
								<a href="#" class="booking-doc-img">
									<?php if(isset($unserInfo->profile_pic)): ?>
										<img src="<?php echo e(asset('public/uploads/user')); ?>/<?php echo e($unserInfo->profile_pic); ?>" alt="User Image" />
									<?php else: ?>
										<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image" />
									<?php endif; ?>
								</a>
								<div class="profile-det-info">
								    <?php if(!empty(Auth::user()->name)): ?>
									    <h3>Dr. <?php echo e(Auth::user()->name); ?></h3>
									<?php else: ?>
										<h3>Dr. No name</h3>
									<?php endif; ?>
									<div class="patient-details">
										<h5 class="mb-0"><i class="fas fa-map-marker-alt"></i><?php if(!empty(Auth::user()->state)): ?> <?php echo e(Auth::user()->state); ?> <?php endif; ?> <?php if(!empty(Auth::user()->country)): ?> <?php echo e(Auth::user()->country); ?> <?php endif; ?></h5>
									</div>
								</div>
							</div>
						</div>
						<div class="dashboard-widget">
							<?php echo $__env->make('trainer/side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
				<div class="col-md-7 col-lg-8 col-xl-9">
					<div class="row">
						<div class="col-md-12">
							<h4 class="mb-4">My Course Content</h4>
							<?php if(session()->has('success')): ?>
								<div class="alert alert-success">
								  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

								</div>
							<?php endif; ?>
							<?php if(session()->has('error')): ?>
								<div class="alert alert-danger">
									<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

								</div>
							<?php endif; ?>
							<div class="submit-section">
								<a href="<?php echo e(url('/trainer/add-course-content')); ?>"><button type="button" class="btn btn-primary submit-btn">Add Course Content</button></a>
							</div><br/>
							<div class="appointment-tab">
								<div class="tab-content">
									<div class="tab-pane show active">
										<div class="card card-table mb-0">
											<div class="card-body">
												<div class="table-responsive">
													<table class="table table-hover table-center mb-0">
														<thead>
															<tr>
																<!--<th>Trainer's Name</th>-->
																<th>Course's Name</th>
																<th>Video</th>
																<th>Pdf Link</th>
																<th>Zoom Link</th>
																<th>Description</th>
																<th>Status</th>
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
														    <?php if(isset($coursecontentInfo)): ?>
																<?php $__currentLoopData = $coursecontentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursecontenlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<tr>
																		<!--<td><?php echo e($coursecontenlist->user_name); ?></td>-->
																		<td><?php echo e($coursecontenlist->course_name); ?></td>
																		<td>
																		    <?php if(isset($coursecontenlist->video)): ?>
																				<video width="200" height="80" controls>
																				  <source src="<?php echo e(asset('public/uploads/course_content/')); ?>/<?php echo e($coursecontenlist->video); ?>" type="video/mp4">
																				  <source src="<?php echo e(asset('public/uploads/course_content/')); ?>/<?php echo e($coursecontenlist->video); ?>" type="video/ogg">
																				  Your browser does not support the video tag.
																				</video>
																			<?php endif; ?>
																		</td>
																		<td align="center">
																		    <?php if(isset($coursecontenlist->pdf_link)): ?>
																		    <a href="<?php echo e(asset('public/uploads/course_content/')); ?>/<?php echo e($coursecontenlist->pdf_link); ?>" target="blank">    
																			   <img src="<?php echo e(asset('public/frontend/img/pdf_logo.PNG')); ?>" height="40px;"></a>
																			<?php endif; ?>
																		</td>
																		<td><?php echo e($coursecontenlist->zoom_link); ?></td>
																		<td><?php echo e($coursecontenlist->description); ?></td>
																		<?php if($coursecontenlist->status==1): ?>
																			<td>Enable</td>
																		<?php else: ?>
																			<td>Disable</td>
																		<?php endif; ?>
																		<td class="text-right">
																			<div class="table-action">
																				<a href="<?php echo e(url('/trainer/edit-course-content/')); ?>/<?php echo e($coursecontenlist->id); ?>" class="btn btn-sm bg-success-light"><i class="fas fa-edit"></i> Edit</a>
																				<a href="<?php echo e(url('/trainer/delete-course-content/')); ?>/<?php echo e($coursecontenlist->id); ?>" class="btn btn-sm bg-danger-light"  onclick="return validateDelete(this);"><i class="fas fa-times"></i> Delete</a>
																			</div>
																		</td>
																	</tr>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
															
														</tbody>
													</table>
													<script>
													  function validateDelete(){ 
														var confirms = confirm('Do you want to delete ?.');
														if(confirms==false){
															return false;
														}
													  }
													</script>
												</div>
											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/trainer/course_content.blade.php ENDPATH**/ ?>