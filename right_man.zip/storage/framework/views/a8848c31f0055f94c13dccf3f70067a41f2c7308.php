<?php $__env->startSection('title', 'Doctors'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Doctors</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Doctors</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
<section class="section section-about">
	<div class="container">
		<div class="row">
			<!--<div class="col-md-10 offset-md-1">
				<div class="section-header text-center">
					<h2>Book Our Doctor</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vitae risus nec dui venenatis dignissim. Aenean vitae metus in augue pretium ultrices. Duis dictum eget dolor vel blandit. </p>
				</div>
			</div>-->
			<div class="col-lg-12">
				<div class="doctor-sliderss">
				    <div class="row">
					
					<?php if(isset($getDoctors)): ?>
						
						<?php $__currentLoopData = $getDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctorList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
							<div class="col-lg-3">
								<div class="profile-widget">
									<div class="doc-img">
										<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>">
											<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($doctorList->profile_pic); ?>">
										</a>
										<a href="" class="fav-btn"> <i class="far fa-bookmark"></i>
										</a>
									</div>
									<div class="pro-content">
										<h3 class="title">
									 <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>"><?php echo e($doctorList->name); ?> <?php echo e($doctorList->last_name); ?></a>
									 <i class="fas fa-check-circle verified"></i>
								  </h3>
										<p class="speciality"><?php echo e($doctorList->doctor_profile_name); ?> <?php echo e($doctorList->specialities_name); ?></p>
										<div class="rating"> <i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<i class="fas fa-star filled"></i>
											<span class="d-inline-block average-rating">(17)</span>
										</div>
										<!--<ul class="available-info">
											<li> <i class="fas fa-map-marker-alt"></i> Florida, USA</li>
											<li> <i class="far fa-clock"></i> Available on Fri, 22 Mar</li>
											<li> <i class="far fa-money-bill-alt"></i> $300 - $1000 <i class="fas fa-info-circle" data-toggle="tooltip" title="Lorem Ipsum"></i>
											</li>
										</ul>-->
										<!--<div class="row row-sm">
											<div class="col-6"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn view-btn">View Profile</a>
											</div>
											<div class="col-6"> <a href="<?php echo e(url('/book-appointment/')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">Book Now</a>
											</div>
										</div>-->
										<div class="row row-sm">
											<div class="offset-0 col-12"> <a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($doctorList->id); ?>" class="btn book-btn">View Profile</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
				    <?php endif; ?>	
						
						
					</div>
				</div> 
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctors.blade.php ENDPATH**/ ?>