<?php $__env->startSection('title', $serviceInfo->name); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Services Details</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title"><?php echo e($serviceInfo->name); ?></h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
    <!-- Content Start -->
	<section class="content" id="services-area">
		<div class="container">
			<div class="row" style="transform: none;">
				<div class="col-lg-8 col-md-12">
					<div class="blog-view">
						<div class="blog blog-single-post">
							<div class="blog-image">
								<a href="javascript:void(0);">
									<img alt="" src="<?php echo e(asset('public/uploads/service/')); ?>/<?php echo e($serviceInfo->image); ?>" class="img-fluid">
								</a>
							</div>
							<h3 class="blog-title"><?php echo e($serviceInfo->name); ?></h3>
							<div class="blog-info clearfix">
								<div class="post-left">
									<ul>
										<li><i class="far fa-clock"></i>  live Session Time : <?php echo e($serviceInfo->session_time); ?> </li>
									</ul>
								</div>
							</div>
							<div class="blog-content">
								<p><?php echo e($serviceInfo->description); ?></p>
							</div>
						</div>
						
						
						<div class="card blog-comments clearfix">
							<div class="card-header">
								<h4 class="card-title">Comments (<?php echo e($getTotalComment); ?>)</h4>
							</div>
							<div class="card-body pb-0">
								<ul class="comments-list">
									<?php $__currentLoopData = $parentComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<div class="comment">
												<div class="comment-author">
													<img class="avatar" alt="" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($comments->user_pic); ?>">
												</div>
												<div class="comment-block"><span class="comment-by"><span class="blog-author-name"><?php echo e($comments->name); ?></span>
													</span>
													<p><?php echo e($comments->comment); ?></p>
													<p class="blog-date"><?php echo e(date('F d, Y',strtotime($comments->created_at))); ?></p>
													<?php if(count($comments->subcomment)<=0): ?>
													  <a class="comment-btn"  style="cursor:pointer;" onclick="showCommentForm('<?php echo e($comments->id); ?>');" ><i class="fas fa-reply"></i> Reply</a>
												    <?php endif; ?>
												</div>
												<?php echo $__env->make('services_comment_form',['comment_IDS' => $comments->id,'parent_id' => $comments->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
											</div>
											<?php if(count($comments->subcomment)): ?>
												<?php $__currentLoopData = $comments->subcomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcommentList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<ul class="comments-list reply">
														<li>
															<div class="comment">
																<div class="comment-author">
																	<img class="avatar" alt="" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($comments->user_pic); ?>">
																</div>
																<div class="comment-block"><span class="comment-by"><span class="blog-author-name"><?php echo e($subcommentList->name); ?></span>
																	</span>
																	<p><?php echo e($subcommentList->comment); ?></p>
																	<p class="blog-date"><?php echo e(date('F d, Y',strtotime($subcommentList->created_at))); ?></p>
																	<a class="comment-btn" style="cursor:pointer;" onclick="showCommentForm('<?php echo e($subcommentList->id); ?>');" ><i class="fas fa-reply"></i> Reply</a>
																</div>
															</div>
														</li>
														<?php echo $__env->make('services_comment_form',['comment_IDS' => $subcommentList->id,'parent_id' => $subcommentList->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
													</ul>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</li>
										
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
							<script>
							    function showCommentForm(formID){
								  $('#comment_'+formID).toggle();
							    }
							</script>
						</div>
						<div class="card new-comment clearfix">
							<div class="card-header">
								<h4 class="card-title">Ask questions</h4>
							</div>
							<div class="card-body">
							    <?php if(session()->has('success')): ?>
									<div class="alert alert-success">
									  <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

									</div>
								<?php endif; ?>
								<?php if(session()->has('error')): ?>
									<div class="alert alert-danger">
										<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

									</div>
								<?php endif; ?>
								<form action="<?php echo e(url('/services_comment_action')); ?>" method="POST" >
									<?php echo csrf_field(); ?>
									<input type="hidden" name="current_url" value="<?php echo e($currentURL); ?>" required>
									<input type="hidden" name="services_id" value="<?php echo e($serviceInfo->id); ?>" required>
									<?php if(!empty(Auth::user()->id)): ?>
										<input type="hidden" name="from_id" value="<?php echo e(Auth::user()->id); ?>" required>
									<?php endif; ?>
									<div class="form-group">
										<label>Name <span class="text-danger">*</span></label>
										<input type="text" name="q_name" class="form-control" required>
									</div>
									<div class="form-group">
										<label>Your Email Address <span class="text-danger">*</span></label>
										<input type="email" name="q_email" class="form-control">
									</div>
									<div class="form-group">
										<label>Question</label>
										<textarea rows="4" name="q_question" class="form-control" required></textarea> 
									</div>
									<div class="submit-section">
										<?php if(auth()->guard()->check()): ?>
											<button class="btn btn-primary submit-btn" type="submit" name="submit" value="submit">Submit</button>
										<?php else: ?> 
											<a href="<?php echo e(url('/login')); ?>"><button class="btn btn-primary submit-btn" type="button" name="submit">Login</button></a>
										<?php endif; ?>
									</div>
								</form>
							</div>
						</div>
						
						
					</div>
				</div>
				<div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">					
					<div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none;">
						<div class="card search-widget">
							<div class="card-body">
								<form class="search-form" method="GET" action="<?php echo e(url('/search-services/')); ?>"> 
									<div class="input-group">								
										<?php if(!empty($_GET['search'])): ?>
										   <input type="text" name="search" value="<?php echo e($_GET['search']); ?>" placeholder="Search..." class="form-control">
										<?php else: ?>
										   <input type="text" name="search" placeholder="Search..." class="form-control">
										<?php endif; ?>										
										<div class="input-group-append">
											<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="card post-widget">
							<div class="card-header">
								<h4 class="card-title">Latest Services</h4>
							</div>
							<div class="card-body">
								<ul class="latest-posts">
									<?php if(isset($latestservice)): ?>
										<?php $__currentLoopData = $latestservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestserviceList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<div class="post-thumb">
												<a href="">
													<img class="img-fluid" src="<?php echo e(asset('public/uploads/service/')); ?>/<?php echo e($latestserviceList->image); ?>" alt="<?php echo e($latestserviceList->image); ?>">
												</a>
											</div>
											<div class="post-info">
												<h4><a href="<?php echo e(url('/services-details/')); ?>/<?php echo e($latestserviceList->slug); ?>"><?php echo e($latestserviceList->name); ?></a></h4>
												<p><?php echo e(date('d M Y',strtotime($latestserviceList->created_at))); ?></p>
											</div>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>	
				</div>	
			</div>	
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/services_details.blade.php ENDPATH**/ ?>