<?php $__env->startSection('title', 'Articles'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Articles</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Articles</h2>
					</div>
				</div>
			</div>
		</section>
<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="doc-review review-listing">
						<div class="row blog-grid-row">
							<?php if(isset($blogList)): ?>
								<?php $__currentLoopData = $blogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
									<div class="col-md-6 col-xl-4 col-sm-12">
										<div class="blog grid-blog">
											<div class="blog-image">
												<a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>">
													<img class="img-fluid" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($blogs->image); ?>" alt="<?php echo e($blogs->name); ?>">
												</a>
											</div>
											<div class="blog-content">
												<ul class="entry-meta meta-item">
													<!--<li>
														<div class="post-author">
															<a href="">
																<img src="<?php echo e(asset('public/frontend/img/doctors/doctor-thumb-01.jpg')); ?>" alt="Post Author"> <span>Dr. Ruby Perrin</span>
															</a>
														</div>
													</li>-->
													<li><i class="far fa-clock"></i> <?php echo e(date('d M Y',strtotime($blogs->created_at))); ?></li>
												</ul>
												<h3 class="blog-title"><a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($blogs->slug); ?>"><?php echo e($blogs->name); ?></a></h3>
												<p class="mb-0"> <?php echo e($blogs->description); ?></p>
											</div>
											<!--<div class="row pt-3">
												<div class="col"><a href="" class="text-success"><i class="far fa-edit"></i> Edit</a>
												</div>
												<div class="col text-right"><a href="javascript:void(0);" class="text-danger" data-toggle="modal" data-target="#deleteNotConfirmModal"><i class="far fa-trash-alt"></i> Inactive</a>
												</div>
											</div>-->
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							
							
						</div>
						<!--<div class="row">
							<div class="col-md-12">
								<div class="blog-pagination">
									<nav>
										<ul class="pagination justify-content-center">
											<li class="page-item disabled"><a class="page-link" href="#" tabindex="-1"><i class="fas fa-angle-double-left"></i></a>
											</li>
											<li class="page-item"><a class="page-link" href="#">1</a>
											</li>
											<li class="page-item active"><a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
											</li>
											<li class="page-item"><a class="page-link" href="#">3</a>
											</li>
											<li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-double-right"></i></a>
											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>-->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/blogs.blade.php ENDPATH**/ ?>