<?php $__env->startSection('title', 'Course Details'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
<section class="breadcrumb-bar">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<nav aria-label="breadcrumb" class="page-breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
						</li>
						<li class="breadcrumb-item active" aria-current="page">Course Details</li>
					</ol>
				</nav>
				<h2 class="breadcrumb-title">Course Details</h2>
			</div>
		</div>
	</div>
</section>
<!-- ./ End of Breadcrumb-bar -->

<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="card">
				<div class="card-body">
				
					<?php if(isset($courseInfo)): ?>
						<div class="doctor-widget">
							<div class="doc-info-left">
								<div class="doctor-img"> 
									<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/course/')); ?>/<?php echo e($courseInfo->image); ?>">
								</div>
								<div class="doc-info-cont">
									<h4 class="doc-name"><?php echo e($courseInfo->name); ?></h4>
									<p class="doc-speciality">
									    <b>Course's Description:</b> <?php echo e($courseInfo->description); ?><br/>
									    <b>Trainer's Name:</b> <?php echo e($courseInfo->user_name); ?><br/>
									    <b>Role:</b> <?php echo e($courseInfo->user_role); ?>

									</p>
									<div class="clini-infos">
										<div class="table-responsive">
											<table class="table table-hover table-center mb-0">
												<thead>
													<tr>
														<th>Video</th>
														<th>Pdf Link</th>
														<th>Zoom Link</th>
														<th>Description</th>
													</tr>
												</thead>
												<?php if(auth()->guard()->check()): ?>
												<tbody>
													<?php if(isset($coursecontentInfo)): ?>
														<?php $__currentLoopData = $coursecontentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseContentList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<tr>
																<td>
																	<video width="200" height="80" controls="">
																		<source src="<?php echo e(asset('/public/uploads/course_content/')); ?>/<?php echo e($courseContentList->video); ?>" type="video/mp4">
																		<source src="<?php echo e(asset('/public/uploads/course_content/')); ?>/<?php echo e($courseContentList->video); ?>" type="video/ogg">
																		  Your browser does not support the video tag.
																	</video>
																</td>
																<td align="center">
																	<a href="<?php echo e(asset('/public/uploads/course_content/')); ?>/<?php echo e($courseContentList->pdf_link); ?>" target="blank">    
																	<img src="<?php echo e(asset('/public/frontend/img/pdf_logo.PNG')); ?>" height="40px;"></a>
																</td>
																<td><?php echo e($courseContentList->zoom_link); ?></td>
																<td><?php echo e($courseContentList->description); ?></td>
															</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</tbody>
												<?php else: ?>
												 <b style="color:red">Please take a subscription for access full content of this course.</b>
												<?php endif; ?>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<div class="clinic-booking"><a class="apt-btn" href="<?php echo e(url('/courses')); ?>">Back</a></div>
					
				</div>
			</div>
			
		</div>
	</section>
	<!-- ./ End of Content -->
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/course_details.blade.php ENDPATH**/ ?>