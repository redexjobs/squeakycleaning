<?php $__env->startSection('title', 'All Courses'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
	<section class="breadcrumb-bar">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-12">
					<nav aria-label="breadcrumb" class="page-breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">Courses</li>
						</ol>
					</nav>
					<h2 class="breadcrumb-title">Courses</h2>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Breadcrumb-bar -->
<section class="section section-about">
	<div class="container">
		<div class="row">
		    <div class="col-md-12 col-lg-4 col-xl-3 theiaStickySidebar">
				<div class="card search-filter">
					<div class="card-header">
						<h4 class="card-title mb-0">Search</h4>
					</div>
					<form action="<?php echo e(url('/search-course-action')); ?>" method="GET">
						<?php echo csrf_field(); ?>
						<div class="card-body">
							<div class="filter-widget">
								<div class="cal-icons">
								    <?php if(!empty($_GET['course_name'])): ?>
										<input type="text" name="course_name" class="form-control" value="<?php echo e($_GET['course_name']); ?>" placeholder="Search course..">
									<?php else: ?>
										<input type="text" name="course_name" class="form-control" placeholder="Search course..">
									<?php endif; ?>
								</div>
							</div>
							<div class="filter-widget">
								<h4>Course Category</h4>
								<?php if(isset($courseCategoryList)): ?>
									<?php  if(!empty($_GET['course_category_id'])) { $getArray = $_GET['course_category_id']; }else{ $getArray = array(); } ?>
									<?php $__currentLoopData = $courseCategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseCategoryLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div>
										<label class="custom_check">
										<?php if(in_array($courseCategoryLists->id,$getArray)): ?>
											<input type="checkbox" name="course_category_id[]" value="<?php echo e($courseCategoryLists->id); ?>" checked>
										<?php else: ?>
											<input type="checkbox" name="course_category_id[]" value="<?php echo e($courseCategoryLists->id); ?>">
										<?php endif; ?>
										<span class="checkmark"></span> <?php echo e($courseCategoryLists->name); ?></label>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</div>
							<div class="btn-search">
								<button type="submit" class="btn btn-block">Search</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="col-md-12 col-lg-8 col-xl-9">
				<div class="doctor-sliderss">
				    <div class="row">
					
						<?php if(isset($courseInfo)): ?>
							
							<?php $__currentLoopData = $courseInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
								<div class="col-lg-4">
									<div class="profile-widget">
										<div class="doc-img">
											<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($courseList->id); ?>">
												<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/course/')); ?>/<?php echo e($courseList->image); ?>">
											</a>
										</div>
										<div class="pro-content">
											<h3 class="title">
												<a href="<?php echo e(url('/doctor-profile')); ?>/<?php echo e($courseList->id); ?>"><?php echo e($courseList->name); ?> </a>
												<i class="fas fa-check-circle verified"></i>
											</h3>
											<p class="speciality"><?php echo e($courseList->description); ?> <br/><br/>
											    <b>Category:</b> <?php echo e($courseList->course_category_name); ?> <br/>
											    <b>Trainer's:</b> <?php echo e($courseList->user_name); ?> <br/>
											    <b>Role:</b> <?php echo e($courseList->user_role); ?>

											</p>
											<div class="row row-sm">
												<div class="col-12"> <a href="<?php echo e(url('/course-details/')); ?>/<?php echo e($courseList->id); ?>" class="btn book-btn">Go To Course Details</a>
												</div>
											</div>
										</div>
									</div>
								</div>
								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						<?php endif; ?>
					
					</div>
				</div> 
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/all_course.blade.php ENDPATH**/ ?>