<?php $__env->startSection('title', 'Blog Category'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Success</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Success</h2>
					</div>
				</div>
			</div>
		</section>
<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
	<section class="content success-page-cont">
		<div class="container-fluid">
			<div class="row justify-content-center">
				<div class="col-lg-6">
					<div class="card success-card">
						<div class="card-body">
							<div class="success-cont">
							    <?php if(session()->has('success')): ?>
									<i class="fas fa-check"></i>
									<h3><?php echo e(session()->get('success')); ?></h3>
								<?php endif; ?>
								<?php if(session()->has('error')): ?>
									<div class="alert alert-danger">
										<strong>Warning!</strong> <?php echo e(session()->get('error')); ?>

									</div>
								<?php endif; ?>
								<!--<p>Appointment booked with <strong>Dr. Kalen Chavez</strong>
									<br>on <strong>12 Nov 2020 5:00PM to 6:00PM</strong>
								</p>-->
								<a href="<?php echo e(url('/')); ?>" class="btn btn-primary view-inv-btn">Back To Home</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/success.blade.php ENDPATH**/ ?>