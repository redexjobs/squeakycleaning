<?php $__env->startSection('title', $blogInfo->name); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Articles Details</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title"><?php echo e($blogInfo->name); ?></h2>
					</div>
				</div>
			</div>
		</section>
<!-- ./ End of Breadcrumb-bar -->
<!-- Content Start -->
		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-md-12">
						<div class="blog-view">
							<div class="blog blog-single-post">
								<div class="blog-image">
									<a href="javascript:void(0);">
										<img alt="" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($blogInfo->image); ?>" class="img-fluid">
									</a>
								</div>
								<h3 class="blog-title"><?php echo e($blogInfo->name); ?></h3>
								<div class="blog-info clearfix">
									<div class="post-left">
										<ul>
											<!--<li>
												<div class="post-author">
													<a href="">
														<img src="assets/img/doctors/doctor-thumb-02.jpg" alt="Post Author"> <span>Dr. Kalen Chavez</span>
													</a>
												</div>
											</li>-->
											<li><i class="far fa-calendar"></i> <?php echo e(date('d M Y',strtotime($blogInfo->created_at))); ?></li>
											<!--<li><i class="far fa-comments"></i>12 Comments</li>-->
											<li><i class="fa fa-tags"></i><?php echo e($blogInfo->category_name); ?></li>
										</ul>
									</div>
								</div>
								<div class="blog-content">
								<?php echo e($blogInfo->description); ?>

								</div>
							</div>
							<!--<div class="card blog-share clearfix">
								<div class="card-header">
									<h4 class="card-title">Share the post</h4>
								</div>
								<div class="card-body">
									<ul class="social-share">
										<li><a href="#" title="Facebook"><i class="fab fa-facebook"></i></a>
										</li>
										<li><a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
										</li>
										<li><a href="#" title="Linkedin"><i class="fab fa-linkedin"></i></a>
										</li>
										<li><a href="#" title="Google Plus"><i class="fab fa-google-plus"></i></a>
										</li>
										<li><a href="#" title="Youtube"><i class="fab fa-youtube"></i></a>
										</li>
									</ul>
								</div>
							</div>
							<div class="card author-widget clearfix">
								<div class="card-header">
									<h4 class="card-title">About Author</h4>
								</div>
								<div class="card-body">
									<div class="about-author">
										<div class="about-author-img">
											<div class="author-img-wrap">
												<a href="">
													<img class="img-fluid rounded-circle" alt="" src="assets/img/doctors/doctor-thumb-02.jpg">
												</a>
											</div>
										</div>
										<div class="author-details"><a href="" class="blog-author-name">Dr. Kalen Chavez</a>
											<p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
										</div>
									</div>
								</div>
							</div>
							<div class="card blog-comments clearfix">
								<div class="card-header">
									<h4 class="card-title">Comments (12)</h4>
								</div>
								<div class="card-body pb-0">
									<ul class="comments-list">
										<li>
											<div class="comment">
												<div class="comment-author">
													<img class="avatar" alt="" src="assets/img/patients/patient4.jpg">
												</div>
												<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Agripina Butcher</span>
													</span>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
													<p class="blog-date">Sep 6, 2021</p>
													<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
												</div>
											</div>
											<ul class="comments-list reply">
												<li>
													<div class="comment">
														<div class="comment-author">
															<img class="avatar" alt="" src="assets/img/patients/patient5.jpg">
														</div>
														<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Rima Sisson</span>
															</span>
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
															<p class="blog-date">Sep 6, 2021</p>
															<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
														</div>
													</div>
												</li>
												<li>
													<div class="comment">
														<div class="comment-author">
															<img class="avatar" alt="" src="assets/img/patients/patient3.jpg">
														</div>
														<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Benigno Bingham</span>
															</span>
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
															<p class="blog-date">Sep 6, 2021</p>
															<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
														</div>
													</div>
												</li>
											</ul>
										</li>
										<li>
											<div class="comment">
												<div class="comment-author">
													<img class="avatar" alt="" src="assets/img/patients/patient6.jpg">
												</div>
												<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Reina Shumate</span>
													</span>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
													<p class="blog-date">September 6, 2021</p>
												</div>
											</div>
										</li>
										<li>
											<div class="comment">
												<div class="comment-author">
													<img class="avatar" alt="" src="assets/img/patients/patient7.jpg">
												</div>
												<div class="comment-block"><span class="comment-by"><span class="blog-author-name">Mariloly Alicea</span>
													</span>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
													<p class="blog-date">September 6, 2021</p>
													<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
							<div class="card new-comment clearfix">
								<div class="card-header">
									<h4 class="card-title">Leave Comment</h4>
								</div>
								<div class="card-body">
									<form>
										<div class="form-group">
											<label>Name <span class="text-danger">*</span>
											</label>
											<input type="text" class="form-control">
										</div>
										<div class="form-group">
											<label>Your Email Address <span class="text-danger">*</span>
											</label>
											<input type="email" class="form-control">
										</div>
										<div class="form-group">
											<label>Comments</label>
											<textarea rows="4" class="form-control"></textarea>
										</div>
										<div class="submit-section">
											<button class="btn btn-primary submit-btn" type="submit">Submit</button>
										</div>
									</form>
								</div>
							</div>-->
							
							
						</div>
					</div>
					<div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar">
						<div class="card search-widget">
							<div class="card-body">
								<form class="search-form" method="GET" action="<?php echo e(url('/blog/search')); ?>">
									<div class="input-group">
										<?php if(!empty($_GET['search'])): ?>
										   <input type="text" name="search" value="<?php echo e($_GET['search']); ?>" placeholder="Search..." class="form-control">
										<?php else: ?>
										   <input type="text" name="search" placeholder="Search..." class="form-control">
										<?php endif; ?>
										<div class="input-group-append">
											<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="card post-widget">
							<div class="card-header">
								<h4 class="card-title">Latest Posts</h4>
							</div>
							<div class="card-body">
								<ul class="latest-posts">
									<?php if(isset($latestPost)): ?>
										<?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestPostList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<div class="post-thumb">
													<a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($latestPostList->slug); ?>">
														<img class="img-fluid" src="<?php echo e(asset('public/uploads/blog/')); ?>/<?php echo e($latestPostList->image); ?>" alt="<?php echo e($latestPostList->name); ?>">
													</a>
												</div>
												<div class="post-info">
													<h4><a href="<?php echo e(url('/blog-details/')); ?>/<?php echo e($latestPostList->slug); ?>"><?php echo e($latestPostList->name); ?></a></h4>
													<p><?php echo e(date('d M Y',strtotime($latestPostList->created_at))); ?></p>
												</div>
											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
						<div class="card category-widget">
							<div class="card-header">
								<h4 class="card-title">Blog Categories</h4>
							</div>
							<div class="card-body">
								<ul class="categories">
									<?php if(isset($blogCat)): ?>
										<?php $__currentLoopData = $blogCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCatList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><a href="<?php echo e(url('/blog/category/')); ?>/<?php echo e($blogCatList->slug); ?>"><?php echo e($blogCatList->name); ?> <span>( <?php echo e($blogCountArray[$blogCatList->id]); ?> )</span></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
						<div class="card tags-widget">
							<div class="card-header">
								<h4 class="card-title">Tags</h4>
							</div>
							<div class="card-body">
								<ul class="tags">
								    <?php if(isset($tagCat)): ?>
										<?php $__currentLoopData = $tagCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagCatList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><a  class="tag" href="<?php echo e(url('/blog/tag/')); ?>/<?php echo e($tagCatList->slug); ?>"><?php echo e($tagCatList->name); ?></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/blog_details.blade.php ENDPATH**/ ?>