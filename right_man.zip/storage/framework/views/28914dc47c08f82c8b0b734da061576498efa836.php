<?php $__env->startSection('title', 'Training'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
		<section class="breadcrumb-bar">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-12">
						<nav aria-label="breadcrumb" class="page-breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Training</li>
							</ol>
						</nav>
						<h2 class="breadcrumb-title">Training</h2>
					</div>
				</div>
			</div>
		</section>
		<!-- ./ End of Breadcrumb-bar -->
    <!-- Content Start -->
	<section class="content mb-2" id="training-area">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-header ">
						<h2>Training Older Adult</h2>
						<p class="m-0">On this page you are allowed to exchange your expertise, in online sessions, and ask each attendee a fee for your expert advice. Olderadultsonline.com provides this service to help older adults share their knowledge, while boosting their own earnings and income.</p>
					</div>	
				</div>
			</div>
			<div class="row">
				<?php if(isset($trainingList)): ?>
					<?php $__currentLoopData = $trainingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-6 col-sm-6 col-lg-4 col-xl-4">
							<div class="blog grid-blog">
								<div class="blog-image">
									<a href="<?php echo e(url('/training-details')); ?>/<?php echo e($training->slug); ?>">
										<img class="img-fluid" src="<?php echo e(asset('public/uploads/training/')); ?>/<?php echo e($training->image); ?>" alt="" />
									</a>
								</div>
								<div class="blog-content">
									<h3 class="blog-title"><a href="<?php echo e(url('/training-details')); ?>/<?php echo e($training->slug); ?>"><?php echo e($training->name); ?></a></h3>
									<p><?php echo e($training->short_description); ?></p>
									<a href="<?php echo e(url('/training-details')); ?>/<?php echo e($training->slug); ?>" class="btn book-btn my-3">Read More</a>
								</div>
							</div>	
						</div>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>		
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/training_page.blade.php ENDPATH**/ ?>