<?php $__env->startSection('title', 'Doctors'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb-bar Start -->
<section class="breadcrumb-bar">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-md-12 col-12">
				<nav aria-label="breadcrumb" class="page-breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
						</li>
						<li class="breadcrumb-item active" aria-current="page">Doctor Profile</li>
					</ol>
				</nav>
				<h2 class="breadcrumb-title">Doctor Profile</h2>
			</div>
		</div>
	</div>
</section>
<!-- ./ End of Breadcrumb-bar -->

<!-- Content Start -->
	<section class="content">
		<div class="container">
			<div class="card">
				<div class="card-body">
					<div class="doctor-widget">
						<div class="doc-info-left">
							<div class="doctor-img"> 
								<img class="img-fluid" alt="User Image" src="<?php echo e(asset('public/uploads/user/')); ?>/<?php echo e($doctorInfo->profile_pic); ?>">
							</div>
							<div class="doc-info-cont">
								<h4 class="doc-name">Dr. <?php echo e($doctorInfo->name); ?> <?php echo e($doctorInfo->last_name); ?></h4>
								<p class="doc-speciality"><?php echo e($doctorInfo->doctor_profile_name); ?></p>
								<p class="doc-department">								
								
								<img src="<?php echo e(asset('public/uploads/specialities/')); ?>/<?php echo e($doctorInfo->specialities_image); ?>" class="img-fluid" alt="<?php echo e($doctorInfo->specialities_name); ?>"><?php echo e($doctorInfo->specialities_name); ?></p>
									
								<div class="rating"><i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star filled"></i>
									<i class="fas fa-star"></i>
									<span class="d-inline-block average-rating">(35)</span>
								</div>
								<div class="clinic-details">
									<p class="doc-location"><i class="fas fa-map-marker-alt"></i> <?php echo e($doctorInfo->state); ?>, <?php echo e($doctorInfo->country); ?> <!--- <a href="javascript:void(0);">Get Directions</a>-->
									</p>
									<ul class="clinic-gallery">
									    <?php if(isset($doctorInfo->features_data)): ?>
											<?php $__currentLoopData = $doctorInfo->features_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuresInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<a href="<?php echo e(asset('public/uploads/features/')); ?>/<?php echo e($featuresInfo['features_image']); ?>" data-fancybox="gallery">
														<img src="<?php echo e(asset('public/uploads/features/')); ?>/<?php echo e($featuresInfo['features_image']); ?>" alt="<?php echo e($featuresInfo['features_name']); ?>">
													</a>
												</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</ul>
								</div>
								<div class="clinic-services">
								    <?php if(isset($doctorInfo->features_data)): ?>
										<?php $__currentLoopData = $doctorInfo->features_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuresInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<span><?php echo e($featuresInfo['features_name']); ?></span>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="doc-info-right">
							<div class="clini-infos">
								<ul>
									<li><i class="far fa-thumbs-up"></i> 99%</li>
									<li><i class="far fa-comment"></i> 35 Feedback</li>
									<li><i class="fas fa-map-marker-alt"></i> <?php echo e($doctorInfo->state); ?>, <?php echo e($doctorInfo->country); ?></li>
									<!--<li><i class="far fa-money-bill-alt"></i> $100 per hour</li>-->
								</ul>
							</div>
							<div class="doctor-action">
								<a href="javascript:void(0)" class="btn btn-white fav-btn"><i class="far fa-bookmark"></i>
								</a>
								<a href="chat.html" class="btn btn-white msg-btn"><i class="far fa-comment-alt"></i>
								</a>
								<a href="javascript:void(0)" class="btn btn-white call-btn" data-toggle="modal" data-target="#voice_call"><i class="fas fa-phone"></i>
								</a>
								<a href="javascript:void(0)" class="btn btn-white call-btn" data-toggle="modal" data-target="#video_call"><i class="fas fa-video"></i>
								</a>
							</div>
							<div class="clinic-booking"><!--<a class="apt-btn" href="<?php echo e(url('/book-appointment')); ?>/<?php echo e($doctorInfo->id); ?>">Book Appointment</a>-->
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="card">
				<div class="card-body pt-0">
					<nav class="user-tabs mb-4">
						<ul class="nav nav-tabs nav-tabs-bottom nav-justified">
							<li class="nav-item"><a class="nav-link active" href="#doc_overview" data-toggle="tab">Overview</a>
							</li>
							<li class="nav-item"><a class="nav-link" href="#doc_reviews" data-toggle="tab">Reviews</a>
							</li>
							<li class="nav-item"><a class="nav-link" href="#doc_business_hours" data-toggle="tab">Business Hours</a>
							</li>
						</ul>
					</nav>
					<div class="tab-content pt-0">
						<div role="tabpanel" id="doc_overview" class="tab-pane fade show active">
							<div class="row">
								<div class="col-md-12 col-lg-9">
									<div class="widget about-widget">
										<?php if(isset($doctorInfo->about_me)): ?>
										   <h4 class="widget-title">About Me</h4>
										   <p><?php echo e($doctorInfo->about_me); ?></p>
										<?php endif; ?>
									</div>
									<!--<div class="widget education-widget">
										<h4 class="widget-title">Education</h4>
										<div class="experience-box">
											<ul class="experience-list">
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content"><a href="#/" class="name">American Dental Medical University</a>
															<div>BDS</div><span class="time">1998 - 2003</span>
														</div>
													</div>
												</li>
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content"><a href="#/" class="name">American Dental Medical University</a>
															<div>MDS</div><span class="time">2003 - 2005</span>
														</div>
													</div>
												</li>
											</ul>
										</div>
									</div>-->
									<!--<div class="widget experience-widget">
										<h4 class="widget-title">Work & Experience</h4>
										<div class="experience-box">
											<ul class="experience-list">
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content"><a href="#/" class="name">Glowing Smiles Family Dental Clinic</a>
															<span class="time">2010 - Present (5 years)</span>
														</div>
													</div>
												</li>
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content"><a href="#/" class="name">Comfort Care Dental Clinic</a>
															<span class="time">2007 - 2010 (3 years)</span>
														</div>
													</div>
												</li>
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content"><a href="#/" class="name">Dream Smile Dental Practice</a>
															<span class="time">2005 - 2007 (2 years)</span>
														</div>
													</div>
												</li>
											</ul>
										</div>
									</div>-->
									<!--<div class="widget awards-widget">
										<h4 class="widget-title">Awards</h4>
										<div class="experience-box">
											<ul class="experience-list">
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content">
															<p class="exp-year">July 2020</p>
															<h4 class="exp-title">Humanitarian Award</h4>
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
														</div>
													</div>
												</li>
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content">
															<p class="exp-year">March 2011</p>
															<h4 class="exp-title">Certificate for International Volunteer Service</h4>
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
														</div>
													</div>
												</li>
												<li>
													<div class="experience-user">
														<div class="before-circle"></div>
													</div>
													<div class="experience-content">
														<div class="timeline-content">
															<p class="exp-year">May 2008</p>
															<h4 class="exp-title">The Dental Professional of The Year Award</h4>
															<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
														</div>
													</div>
												</li>
											</ul>
										</div>
									</div>-->
									<!--<div class="service-list">
										<h4>Services</h4>
										<ul class="clearfix">
											<li>Tooth cleaning</li>
											<li>Root Canal Therapy</li>
											<li>Implants</li>
											<li>Composite Bonding</li>
											<li>Fissure Sealants</li>
											<li>Surgical Extractions</li>
										</ul>
									</div>-->
									<!--<div class="service-list">
										<h4>Specializations</h4>
										<ul class="clearfix">
											<li>Children Care</li>
											<li>Dental Care</li>
											<li>Oral and Maxillofacial Surgery</li>
											<li>Orthodontist</li>
											<li>Periodontist</li>
											<li>Prosthodontics</li>
										</ul>
									</div>-->
								</div>
							</div>
						</div>
						
						<div role="tabpanel" id="doc_reviews" class="tab-pane fade">
							<div class="widget review-listing">
								<ul class="comments-list">
									<li>
										<div class="comment">
											<img class="avatar avatar-sm rounded-circle" alt="User Image" src="<?php echo e(asset('public/frontend/img/patients/patient.jpg')); ?>">
											<div class="comment-body">
												<div class="meta-data"><span class="comment-author">Muneer Vickery</span>
													<span class="comment-date">Reviewed 2 Days ago</span>
													<div class="review-count rating"><i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star"></i>
													</div>
												</div>
												<p class="recommended"><i class="far fa-thumbs-up"></i> I recommend the doctor</p>
												<p class="comment-content">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation. Curabitur non nulla sit amet nisl tempus</p>
												<div class="comment-reply">
													<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
													<p class="recommend-btn"><span>Recommend?</span>
														<a href="#" class="like-btn"><i class="far fa-thumbs-up"></i> Yes</a>
														<a href="#" class="dislike-btn"><i class="far fa-thumbs-down"></i> No</a>
													</p>
												</div>
											</div>
										</div>
										<ul class="comments-reply">
											<li>
												<div class="comment">
													<img class="avatar avatar-sm rounded-circle" alt="User Image" src="<?php echo e(asset('public/frontend/img/patients/patient1.jpg')); ?>">
													<div class="comment-body">
														<div class="meta-data"><span class="comment-author">Aliena Stauffer</span>
															<span class="comment-date">Reviewed 3 Days ago</span>
															<div class="review-count rating"><i class="fas fa-star filled"></i>
																<i class="fas fa-star filled"></i>
																<i class="fas fa-star filled"></i>
																<i class="fas fa-star filled"></i>
																<i class="fas fa-star"></i>
															</div>
														</div>
														<p class="comment-content">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Curabitur non nulla sit amet nisl tempus</p>
														<div class="comment-reply">
															<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
															<p class="recommend-btn"><span>Recommend?</span>
																<a href="#" class="like-btn"><i class="far fa-thumbs-up"></i> Yes</a>
																<a href="#" class="dislike-btn"><i class="far fa-thumbs-down"></i> No</a>
															</p>
														</div>
													</div>
												</div>
											</li>
										</ul>
									</li>
									<li>
										<div class="comment">
											<img class="avatar avatar-sm rounded-circle" alt="User Image" src="<?php echo e(asset('public/frontend/img/patients/patient2.jpg')); ?>">
											<div class="comment-body">
												<div class="meta-data"><span class="comment-author">Yegor Aguirre</span>
													<span class="comment-date">Reviewed 4 Days ago</span>
													<div class="review-count rating"><i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star filled"></i>
														<i class="fas fa-star"></i>
													</div>
												</div>
												<p class="comment-content">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation. Curabitur non nulla sit amet nisl tempus</p>
												<div class="comment-reply">
													<a class="comment-btn" href="#"><i class="fas fa-reply"></i> Reply</a>
													<p class="recommend-btn"><span>Recommend?</span>
														<a href="#" class="like-btn"><i class="far fa-thumbs-up"></i> Yes</a>
														<a href="#" class="dislike-btn"><i class="far fa-thumbs-down"></i> No</a>
													</p>
												</div>
											</div>
										</div>
									</li>
								</ul>
								<div class="all-feedback text-center"><a href="#" class="btn btn-primary btn-sm">Show all feedback <strong>(167)</strong></a>
								</div>
							</div>
							<div class="write-review">
								<h4>Write a review for <strong>Dr. Kalen Chavez</strong></h4>
								<form>
									<div class="form-group">
										<label>Review</label>
										<div class="star-rating">
											<input id="star-5" type="radio" name="rating" value="star-5">
											<label for="star-5" title="5 stars"><i class="active fa fa-star"></i>
											</label>
											<input id="star-4" type="radio" name="rating" value="star-4">
											<label for="star-4" title="4 stars"><i class="active fa fa-star"></i>
											</label>
											<input id="star-3" type="radio" name="rating" value="star-3">
											<label for="star-3" title="3 stars"><i class="active fa fa-star"></i>
											</label>
											<input id="star-2" type="radio" name="rating" value="star-2">
											<label for="star-2" title="2 stars"><i class="active fa fa-star"></i>
											</label>
											<input id="star-1" type="radio" name="rating" value="star-1">
											<label for="star-1" title="1 star"><i class="active fa fa-star"></i>
											</label>
										</div>
									</div>
									<div class="form-group">
										<label>Title of your review</label>
										<input class="form-control" type="text" placeholder="If you could say it in one sentence, what would you say?">
									</div>
									<div class="form-group">
										<label>Your review</label>
										<textarea id="review_desc" maxlength="100" class="form-control"></textarea>
										<div class="d-flex justify-content-between mt-3"><small class="text-muted"><span id="chars">100</span> characters remaining</small>
										</div>
									</div>
									<hr>
									<div class="form-group">
										<div class="terms-accept">
											<div class="custom-checkbox">
												<input type="checkbox" id="terms_accept">
												<label for="terms_accept">I have read and accept <a href="#">Terms &amp; Conditions</a>
												</label>
											</div>
										</div>
									</div>
									<div class="submit-section">
										<button type="submit" class="btn btn-primary submit-btn">Add Review</button>
									</div>
								</form>
							</div>
						</div>
						<div role="tabpanel" id="doc_business_hours" class="tab-pane fade">
							<div class="row">
								<div class="col-md-6 offset-md-3">
									<div class="widget business-widget">
										<div class="widget-content">
											<div class="listing-hours">
												<!--<div class="listing-day current">
													<div class="day">Today <span>5 Nov 2020</span>
													</div>
													<div class="time-items"><span class="open-status"><span class="badge bg-success-light">Open Now</span></span><span class="time">07:00 AM - 09:00 PM</span>
													</div>
												</div>-->
												<div class="listing-day">
													<div class="day">Monday</div>
													<div class="time-items">
													    <?php if(!empty($getMondaySlot)): ?>
															<?php $__currentLoopData = $getMondaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mondaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($mondaySlot->from_time); ?> <?php echo e($mondaySlot->from_am_pm); ?> - <?php echo e($mondaySlot->to_time); ?> <?php echo e($mondaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day">
													<div class="day">Tuesday</div>
													<div class="time-items">
													    <?php if(!empty($getTuesdaySlot)): ?>
															<?php $__currentLoopData = $getTuesdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuesdaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($tuesdaySlot->from_time); ?> <?php echo e($tuesdaySlot->from_am_pm); ?> - <?php echo e($tuesdaySlot->to_time); ?> <?php echo e($tuesdaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day">
													<div class="day">Wednesday</div>
													<div class="time-items">
													    <?php if(!empty($getWednesdaySlot)): ?>
															<?php $__currentLoopData = $getWednesdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wednesdaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($wednesdaySlot->from_time); ?> <?php echo e($wednesdaySlot->from_am_pm); ?> - <?php echo e($wednesdaySlot->to_time); ?> <?php echo e($wednesdaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day">
													<div class="day">Thursday</div>
													<div class="time-items">
													    <?php if(!empty($getThursdaySlot)): ?>
															<?php $__currentLoopData = $getThursdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thursdaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($thursdaySlot->from_time); ?> <?php echo e($thursdaySlot->from_am_pm); ?> - <?php echo e($thursdaySlot->to_time); ?> <?php echo e($thursdaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day">
													<div class="day">Friday</div>
													<div class="time-items">
													    <?php if(!empty($getFridaySlot)): ?>
															<?php $__currentLoopData = $getFridaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fridaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($fridaySlot->from_time); ?> <?php echo e($fridaySlot->from_am_pm); ?> - <?php echo e($fridaySlot->to_time); ?> <?php echo e($fridaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day">
													<div class="day">Saturday</div>
													<div class="time-items">
													    <?php if(!empty($getSaturdaySlot)): ?>
															<?php $__currentLoopData = $getSaturdaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saturdaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($saturdaySlot->from_time); ?> <?php echo e($saturdaySlot->from_am_pm); ?> - <?php echo e($saturdaySlot->to_time); ?> <?php echo e($saturdaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="listing-day closed">
													<div class="day">Sunday</div>
													<div class="time-items">
													    <?php if(!empty($getSundaySlot)): ?>
															<?php $__currentLoopData = $getSundaySlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sundaySlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<span class="time"><?php echo e($sundaySlot->from_time); ?> <?php echo e($sundaySlot->from_am_pm); ?> - <?php echo e($sundaySlot->to_time); ?> <?php echo e($sundaySlot->to_am_pm); ?> <i class="fa fa-clock"></i></span>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
															<span class="time"><span class="badge bg-danger-light">Closed</span></span>
														<?php endif; ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ./ End of Content -->
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/doctor_details.blade.php ENDPATH**/ ?>