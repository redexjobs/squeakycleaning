	<nav class="dashboard-menu">
		<ul>
			<li class="<?php echo e(Request::is('trainer/dashboard') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/dashboard')); ?>"><i class="fas fa-columns"></i>
					<span>Dashboard</span>
				</a>
			</li>
			<li class="<?php echo e(Request::is('trainer/profile-setting') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/profile-setting')); ?>"><i class="fas fa-user-cog"></i>
					<span>Profile Settings</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(url('/trainer/chat')); ?>"><i class="fas fa-comments"></i>
					<span>Chat</span>
					<!--<small class="unread-msg">0</small>-->
				</a>
			</li>
			<li class="<?php echo e(Request::is('trainer/course') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/add-new-course') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/edit-course/') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/course')); ?>"><i class="fas fa-columns"></i>
					<span>Course</span>
				</a>
			</li>
			<li class="<?php echo e(Request::is('trainer/course-content') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/add-course-content') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/edit-course-content/') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/course-content')); ?>"><i class="fas fa-columns"></i>
					<span>Course Content</span> 
				</a>
			</li>
			<li class="<?php echo e(Request::is('trainer/training') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/add-new-training') ? 'active' : ''); ?> <?php echo e(Request::is('trainer/edit-training/') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/training')); ?>"><i class="fas fa-columns"></i>
					<span>Training</span>
				</a>
			</li>
			<li class="<?php echo e(Request::is('trainer/change-password') ? 'active' : ''); ?>">
				<a href="<?php echo e(url('/trainer/change-password')); ?>"><i class="fas fa-lock"></i>
					<span>Change Password</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(url('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i>
					<span>Logout</span>
				</a>
			</li>
		</ul>
	</nav><?php /**PATH /home/u948355928/domains/olderadultsonline.com/public_html/resources/views/trainer/side_nav.blade.php ENDPATH**/ ?>